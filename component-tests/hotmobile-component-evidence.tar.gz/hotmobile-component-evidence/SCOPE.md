# Scope of the HotMobile 2027 paper and artifact

This directory is deliberately narrower than the surrounding research
repository. It contains the manuscript, a seven-test harness for the paper's
reported shared-label results, fresh execution evidence, a digest-bound copy of
the historical 16-added-test/87-pass method archive, relevant Android source
excerpts, and an offline verifier.

## Fresh paper-scoped execution

The project-authored test harness is a tests-only patch to AOSP's existing
`JobStatusTest`. It changes no production file. Seven tests support the paper:

1. the charging-first overlap trace;
2. the same trace without intermediate queries;
3. the reverse closing order;
4. a one-contributor control;
5. a nonoverlap control;
6. membership removal; and
7. the two-reason ranking reversal.

We formed a patch containing only those tests and their required helpers, then
ran the entire test class against the pinned Android 17 checkout. The fresh run
passed all 78 tests: 71 pre-existing and seven added. This run is the primary
execution evidence for the paper's reported trace outcomes.

## Historical count provenance

The manuscript reports an earlier validation run containing 71 pre-existing
and 16 added tests, all 87 passing. The seven paper tests were among those 16.
The exact historical patch, patched test source, result, and logs are retained
under `artifact/evidence/historical-run/` because the method explicitly names
the additional coverage families. They substantiate that method claim; their
unreported outcomes are not additional paper findings. A compact name-hash
projection under `historical-count/` lets the verifier relate the 71 upstream
methods and seven active paper-result methods to the complete 87-pass set
while keeping the result claims limited to the seven active tests' eight logged
observations.

## Evidence classes

- **Executed:** the fresh direct `JobStatusTest` run: 78 passed, zero failed,
  zero ignored, and zero assumption-failed.
- **Observed or asserted:** implementation values, reason-key presence, and the
  focal checkpoint sequence.
- **Test-supplied and independently checked:** union and job-age fields in the
  emitted records.
- **Derived:** additive references, interval unions, reference rankings, and
  the four-trace fixed-rate contradiction.
- **Source-traced only:** the public Binder/client return path and controller
  routes capable of supplying the studied orders.
- **Not executed or measured:** an app-facing call, either production
  controller route, practical prevalence, phone-observed seconds, or the
  correctness or overhead of a repair.

## Explicitly outside this paper

Do not use sibling-repository material to extend this artifact with the Android
probe app, device-study experiments, stock-device matrices, cross-version or
other scheduling-API studies, unreported outcomes from the digest-bound historical
archive, or repair experiments. The paper also does not identify Android's
intended aggregation rule.

## What self-contained means

After copying, renaming, or making this directory the root of a Git repository,
`python3 -I verify_artifact.py` must still pass. That offline check uses local
files only and rejects symlinks, undeclared release files or directories, and
changes to digest-bound content. Root `.git` metadata and files under `build/`
are outside the release inventory. Re-executing the Android tests is a separate
operation requiring a compatible AOSP build environment and emulator, as
described in `artifact/REPRODUCE.md`.

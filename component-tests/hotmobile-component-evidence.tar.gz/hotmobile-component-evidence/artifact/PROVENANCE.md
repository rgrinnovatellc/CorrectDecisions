# Provenance

## Fresh scoped run

- AOSP tag: `android-17.0.0_r1`
- `frameworks/base`: `94b4c163b7dfe5ce3607f7bb8456f9573f7de57d`
- Run interval: `2026-08-13T04:35:27Z` to `2026-08-13T04:51:43Z`
- Target: `FrameworksMockingServicesTests_com_android_server_job`
- Class: `com.android.server.job.controllers.JobStatusTest`
- Fingerprint:
  `Android/sdk_phone64_x86_64/emu64x:Baklava/CP2A.260605.016/eng.upgaut:userdebug/test-keys`
- Patch SHA-256: `bb49a744474ecbd96a2c322a7ce958b2ddf69fc14d81829dec8961334b50c6b8`
- Executed patched-source SHA-256:
  `f9d949299765cdf423c428660ba5d4f273d5ca7f416fbd36940fa784ea2cb8ab`
- Test-result SHA-256:
  `00e798abd049e1c4d09601514787466052697c329065e8bc3640f56e855894cf`

`evidence/scoped-run/result.json` indexes the run files. Its execution record
also commits to the installed test APK's digest and byte count. The APK is not
included because it is the broad upstream module containing many unrelated
tests; the exact seven-test scoped patch, reconstructed executed source, and
run outputs are included instead.

The released `atest.log` normalizes the local checkout and home-directory
prefixes to `<AOSP_ROOT>` and `<USER_HOME>`. The execution record preserves the
pre-normalization digest as well as the digest of the released log; test output
and timestamps are unchanged.

## Historical count record

The exact earlier 16-added-test/87-pass evidence archive is under
`evidence/historical-run/`. The verifier checks its patch reconstruction, file
digests, and per-test outcomes. `evidence/historical-count/` is a compact
name-hash projection of that same run. The historical archive substantiates the
method's coverage and count; only the fresh seven-test run is used for the
paper's reported trace values and derived shared-label results.

## Source snapshots and trust

`source/MANIFEST.json` records each excerpt's AOSP project, project revision,
upstream path, full upstream file digest, exact line ranges, and excerpt digest.
Android notices are under `LICENSES/`.

`artifact-manifest.json` binds every non-generated package file except itself;
the verifier also pins critical evidence and the exact release inventory.
Generated `build/` files are intentionally outside that manifest. This is not a
signed attestation. The Git commit or release-archive digest that distributes
the package is the external trust anchor.

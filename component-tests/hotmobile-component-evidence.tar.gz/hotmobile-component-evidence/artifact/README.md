# Paper-scoped artifact

This artifact contains the test harness, execution evidence, trace definitions,
and Android source excerpts needed to audit the paper's shared-label results
and source-derived chain.

- `tests/` holds the seven-test characterization patch and pristine upstream
  test source.
- `evidence/scoped-run/` holds the fresh 78-pass run and executed patched source.
- `evidence/historical-run/` holds the digest-bound 16-added-test/87-pass method archive.
- `evidence/historical-count/` holds its compact count/name-hash projection.
- `source/excerpts/` holds line-numbered excerpts; `source/MANIFEST.json` binds
  each excerpt to its upstream project, revision, path, and full-file digest.
- `traces.json` states only interval inputs; the verifier derives union,
  additive, age, ranking, and fixed-rate results.

Production `JobStatus.java` was unchanged. The scoped patch modifies only
`JobStatusTest.java`. Run from the parent directory:

```sh
python3 -I verify_artifact.py
```

Do not substitute the surrounding repository's Android probe app. This paper
did not execute the app-facing API.

Comments inside the digest-bound executed test source are test-author context, not
API-contract evidence. In particular, the ranking result supports the paper's
conditional comparison hazard; it does not establish how developers actually
rank actions or which repair would have the greatest causal effect.

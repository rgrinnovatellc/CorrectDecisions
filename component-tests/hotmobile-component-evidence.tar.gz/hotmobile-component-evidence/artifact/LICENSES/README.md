# Source attribution

The pristine test source and line-numbered Android source excerpts are derived
from the Android Open Source Project. Excerpted source lines are preserved, with
generated range headings and line labels added for auditability. The upstream
Java and AIDL files carry Apache License 2.0 headers; the corresponding
`frameworks/base` notice is included here. The tests-only patch also contains
the authors' inserted test code. The API-signature excerpt comes from
`prebuilts/sdk`; its corresponding notice is also included.

The small `build/release` flag-value excerpt preserves the source lines with
generated range headings and line labels. Its exact project revision, upstream
path, complete-file digest, and byte count are in `../source/MANIFEST.json`.

No license is asserted here for the authors' manuscript or project-authored
verification and documentation files.

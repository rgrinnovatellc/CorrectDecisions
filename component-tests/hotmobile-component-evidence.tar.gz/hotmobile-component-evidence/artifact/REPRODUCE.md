# Reproduction

## Verify the archived evidence

No Android checkout is needed:

```sh
cd hotmobile2027
python3 -I verify_artifact.py
```

## Rerun the seven paper tests

Use a clean AOSP checkout synced to `android-17.0.0_r1`, with
`frameworks/base` at the revision in `PROVENANCE.md`, an initialized Android
build shell, and a compatible API 37 userdebug emulator. From the AOSP checkout
root:

```sh
source build/envsetup.sh
lunch sdk_phone64_x86_64 trunk_staging userdebug
```

Apply the patch from the `frameworks/base` Git repository root, not the
multi-repository AOSP root:

```sh
cd frameworks/base
git apply --check /path/to/hotmobile2027/artifact/tests/0001-hotmobile-seven-result-tests.patch
git apply /path/to/hotmobile2027/artifact/tests/0001-hotmobile-seven-result-tests.patch
git diff --check
cd ../..
atest -s SERIAL FrameworksMockingServicesTests_com_android_server_job:com.android.server.job.controllers.JobStatusTest
```

The expected class result is 78 passed: 71 upstream plus seven added, with zero
failed, ignored, or assumption-failed. Capture any rerun separately; do not
replace this release's evidence. Then reverse the patch from `frameworks/base`
and confirm that repository is clean.

Matching the archived fingerprint gives the closest replication. A different
compatible userdebug image is a new rerun, not the identical substrate. This
procedure still does not execute the app-facing API or production controller
routes.

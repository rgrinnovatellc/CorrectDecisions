# Claim and evidence map

| Paper claim | Classification | Local evidence |
| --- | --- | --- |
| The historical method added 16 `@EnableFlags` tests only to `JobStatusTest`, ran against unchanged `JobStatus`, and recorded all 87 tests passing | executed-method provenance | digest-bound historical archive and verifier |
| The public documentation defines per-reason duration statistics and permits simultaneous public reasons, but gives no rule for overlapping internal contributors mapped to the same reason | documentation- and source-derived | `source/excerpts/JobScheduler.java.txt` and `source/excerpts/JobStatus.java.txt` |
| In the main Restricted trace, where the app requests none of the three focal constraints, charging, battery-not-low, and idle are policy-added, map to `APP_STANDBY`, and share one start/total pair | source-derived | `source/excerpts/JobStatus.java.txt` |
| For a mapped reason, an unsatisfied transition stores or overwrites one shared start; a satisfied transition consumes and deletes that start or uses the enqueue fallback; a query extends only reasons that remain current | source-derived | `source/excerpts/JobStatus.java.txt`, especially upstream lines 2688--2758 |
| The direct focal test is not registered with the scheduler service, and an unsatisfied implicit constraint keeps its `JobStatus` unready; the paper therefore treats the interval as a modeled pending window rather than an observed scheduler-service lifetime | test- and source-derived | `evidence/scoped-run/JobStatusTest.executed.java` and `source/excerpts/JobStatus.java.txt`, especially upstream lines 140--164, 690--704, and 2929--2946 |
| Focal queries return `0, 0, 10, 50` | executed assertion | scoped executed test source and 78-pass result |
| The focal final implementation value is 50 | observed | scoped device log |
| Focal union is 30 and record age is 40 | test-supplied and independently checked | scoped device log plus `traces.json` |
| Focal additive reference is 40 | derived | `traces.json` and verifier |
| Query-free and reverse-order cases return 50 | observed | scoped device log and passing results |
| One-contributor and nonoverlap cases return 30 and 20 | observed | scoped device log and passing results |
| Membership removal returns an `APP_STANDBY` key with value zero | observed | scoped device log and executed test source |
| No fixed accrual rate based only on current contributors fits all four selected traces | derived across executed cases | `traces.json` and verifier |
| Implementation ranks `APP_STANDBY` 40 above requested battery-not-low 25; under either reference, requested battery-not-low 25 ranks above `APP_STANDBY` (20 additive; 15 union) | observed plus derived | scoped device log, `traces.json`, and verifier |
| The focal query returning 50 at time 40 and ranking query returning 40 at time 35 emit no warning; the focal intermediate query at time 30 does | test- and log-derived | executed test source and ordered scoped device-log slices |
| Source permits the two studied controller orders | source-traced only | controller/service excerpts |
| `JobStatus` values reach the public API without reaggregation | source-traced only | Binder/service/client excerpts |
| The final API 37 public signature includes the method, and the release flag is enabled/read-only | release-source evidence | API-signature, finalized-flag, and flag-value excerpts |

The artifact does not establish app-visible end-to-end values, practical
prevalence, actual developer behavior, Android's intended aggregation rule, or
the correctness or overhead of any repair.

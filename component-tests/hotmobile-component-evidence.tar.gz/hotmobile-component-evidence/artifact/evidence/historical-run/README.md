# Digest-bound historical method archive

This directory preserves the exact retained evidence bundle from the
16-added-test execution described in the paper's method and provenance
paragraphs. It makes the stated 71+16=87 result locally auditable without
consulting the surrounding repository; it does not archive an emulator image
or executable APK.

The active, readable paper-result harness is the seven-test patch under
`../../tests/`, and every reported trace value and derived shared-label result
is backed by its fresh 78-pass run under `../scoped-run/`. The files here have a narrower
role: they substantiate the manuscript's historical test count and the
additional coverage families named in the method. Outcomes or comments found
only here are not additional paper claims.

The verifier checks this archive's exact file inventory and digests, applies
the historical patch to the same pristine 71-test source, reconstructs the
archived patched source, and checks that the archived result contains exactly
87 passed tests with no failures or ignored tests. The archive is digest-bound
and therefore tamper-evident; do not replace it with a later rerun.

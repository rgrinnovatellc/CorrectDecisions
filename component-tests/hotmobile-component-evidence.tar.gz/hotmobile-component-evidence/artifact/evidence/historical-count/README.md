# Historical count provenance

The manuscript describes the original validation run: 71 pre-existing tests
plus 16 added tests, all 87 passing. Seven additions are the paper-result tests
reproduced by the active harness.

This directory is a compact projection of the exact archive in
`../historical-run/`. It retains aggregate outcomes, file commitments, and
SHA-256 hashes of the 87 passed-test names. The verifier regenerates the
projection from the digest-bound result, checks that it contains the 71 upstream
methods and seven active paper-result tests, and finds nine other additions.
Those additions substantiate only the extra coverage named in the method.
Every reported trace value and derived shared-label result is independently
backed by the fresh seven-test run in `../scoped-run/`.

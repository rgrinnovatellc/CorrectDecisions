#!/usr/bin/env python3
"""Verify the rescued CP31 JobStatus monotonicity evidence.

This verifier is self-contained and uses only Python's standard library.  It
establishes integrity and internal consistency; the surrounding Git commit or
release-archive digest remains the external authenticity anchor.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import sys
import tarfile
from datetime import datetime
from pathlib import Path, PurePosixPath


if sys.version_info < (3, 10):
    raise SystemExit("FAIL: Python 3.10 or newer is required")

ROOT = Path(__file__).resolve().parent
RAW = ROOT / "raw"
SOURCE = ROOT / "source"
RAW_INVENTORY = ROOT / "raw-inventory.json"
PAYLOAD_MANIFEST = ROOT / "payload-manifest.json"
EXECUTION = ROOT / "execution.json"
RESULT = ROOT / "result.json"
SCAN_REPORT = ROOT / "scan-report.json"

FOCUSED_RESULT = RAW / "focused/test_result"
FOCUSED_LOG = RAW / "focused/atest.log"
FULL_RESULT = RAW / "full-class/test_result"
FULL_LOG = RAW / "full-class/atest.log"
FOCUSED_HOST = RAW / (
    "focused/log/invocation_10806975250006360782/"
    "inv_14592751537831796891/host_log_15752925754280551735.txt"
)
FULL_HOST = RAW / (
    "full-class/log/invocation_17152683438745387698/"
    "inv_13843928443299427251/host_log_6603015523440269780.txt"
)
FULL_DEVICE = RAW / (
    "full-class/log/invocation_17152683438745387698/"
    "inv_13843928443299427251/"
    "device_logcat_setup_emulator-5580_6718588232266098484.txt"
)

PRISTINE_TEST = SOURCE / "JobStatusTest.pristine.java"
MONOTONIC_TEST = SOURCE / "JobStatusTest.monotonicity.java"
PATCH = SOURCE / "monotonicity.diff"
BASELINE_JOB_STATUS = SOURCE / "JobStatus.java"
MONOTONIC_JOB_STATUS = SOURCE / "JobStatus.monotonicity.java"
MOCKING_BP = SOURCE / "mockingservicestests.Android.bp"
SERVICE_BP = SOURCE / "service-jobscheduler.Android.bp"
SOURCE_METADATA = SOURCE / "metadata.json"

EXPECTED_CLASS = "com.android.server.job.controllers.JobStatusTest"
EXPECTED_METHOD = (
    "testPendingReasonStats_"
    "samePublicReasonDurationDecreasesWithoutResetCharacterization"
)
EXPECTED_SKIPS = {
    "testGetPendingJobReasonStats",
    "testGetPendingJobReasonStats_BatterySaver",
    "testGetPendingJobReasonStats_StillPending",
    "testGetPendingJobReasonStats_correctlyAccumulates",
}
EXPECTED_REVISION = "94b4c163b7dfe5ce3607f7bb8456f9573f7de57d"
EXPECTED_COMMIT = "27c982edb84426f94ed569ac782c0a0991ebe362"
EXPECTED_TREE = "284c3b79ab6a2c52f59db27a4d0141df5bfc84f7"
EXPECTED_FINGERPRINT = (
    "google/sdk_gphone16k_x86_64/emu64xa16k:17/CP31.260618.005/"
    "15731206:userdebug/dev-keys"
)
EXPECTED_APK_CACHE_DIGEST = (
    "85f3fb7975c6435005bf06fb5d9bab123e3cfca7f21b8a6eea4f12fcbce5b410"
)
EXPECTED_PAYLOAD_MANIFEST_SHA256 = (
    "4c94c804c989a5f5e5b0f6f6b0d034d082f009ba29960cbf2b12bed6166d7c89"
)

EXPECTED_HASHES = {
    "raw/focused/test_result":
        "503fc58af21bf57e7f57b7d0298b8ebd6dc26e8215695d5e16c89e93d9268937",
    "raw/focused/atest.log":
        "0186cfbe7212c1b8ce5358bc01cb21039d81df7f8cbbd51589197a5c2f44556f",
    "raw/full-class/test_result":
        "266521ecbd55202a81b794c77ae27d1becc21ed991bfcd9382facd5037f3fd88",
    "raw/full-class/atest.log":
        "365725cec584de307a6ad04f39bb02f3c320a575403cce8f1960b8e4fe3fbc9c",
    "archives/focused-atest-result.tar.gz":
        "1d5e96f14cebc3b8fbff19295e8d237649520e42e16cc97166ce55d3a065290f",
    "archives/full-class-atest-result.tar.gz":
        "5662f8cdad1bdf83e37858818e82ad853f51f6666664e663b0bc104692c5809f",
    "source/JobStatusTest.pristine.java":
        "6393bf27be4ae1baa7a0e4bbf7ae7bfbc1965cd4d97fa6456490eb6f577b8cbe",
    "source/JobStatusTest.monotonicity.java":
        "1680a76d53574ebf81cb18b9a8906bcc28613b4a775665ea276986f2e925afbf",
    "source/JobStatus.java":
        "2a8fbe2a30f1967d677ebc9303446bd6833cb280bab11f3190a2bdb87450e7ba",
    "source/JobStatus.monotonicity.java":
        "2a8fbe2a30f1967d677ebc9303446bd6833cb280bab11f3190a2bdb87450e7ba",
    "source/monotonicity.diff":
        "d58ab76e351812390a1fbb8bc68a4b1676234a0dd59a0ec92396f6dd1e9bcee5",
    "source/r1-baseline-repo-manifest.xml":
        "aed6cab4ac2995410b9b9feed2c20629b2b5db42d297ca109232bcdd56c923f1",
}

HEX64 = re.compile(r"[0-9a-f]{64}\Z")
TEST_RE = re.compile(r"\bpublic\s+void\s+(test[A-Za-z0-9_]+)\s*\(", re.MULTILINE)
ASSUMPTION_PHRASE = (
    "Flag android.app.job.enhanced_pending_and_stop_reasons_api code is optimized."
)


class VerificationError(RuntimeError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise VerificationError(message)


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as stream:
        for block in iter(lambda: stream.read(1024 * 1024), b""):
            digest.update(block)
    return digest.hexdigest()


def load_json(path: Path) -> object:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise VerificationError(f"cannot parse {path.relative_to(ROOT)}: {exc}") from exc


def checked_relative(value: object) -> str:
    require(isinstance(value, str) and value, "path must be a nonempty string")
    require("\\" not in value and not any(ord(char) < 32 for char in value),
            f"unsafe path: {value!r}")
    path = PurePosixPath(value)
    require(not path.is_absolute() and ".." not in path.parts and "." not in path.parts,
            f"unsafe path: {value}")
    require(path.as_posix() == value, f"noncanonical path: {value}")
    return value


def scan_tree(root: Path) -> tuple[set[str], set[str]]:
    files: set[str] = set()
    dirs: set[str] = set()

    def visit(directory: Path) -> None:
        for entry in os.scandir(directory):
            mode = entry.stat(follow_symlinks=False).st_mode
            rel = Path(entry.path).relative_to(root).as_posix()
            require(not stat.S_ISLNK(mode), f"symlink forbidden: {rel}")
            if stat.S_ISDIR(mode):
                dirs.add(rel)
                visit(Path(entry.path))
            elif stat.S_ISREG(mode):
                files.add(rel)
            else:
                raise VerificationError(f"non-regular entry forbidden: {rel}")

    visit(root)
    return files, dirs


def verify_payload_manifest() -> None:
    require(sha256(PAYLOAD_MANIFEST) == EXPECTED_PAYLOAD_MANIFEST_SHA256,
            "payload-manifest digest mismatch")
    data = load_json(PAYLOAD_MANIFEST)
    require(isinstance(data, dict) and set(data) == {"schema_version", "files"}
            and data["schema_version"] == 1, "unsupported payload manifest")
    entries = data["files"]
    require(isinstance(entries, list) and entries, "empty payload manifest")
    paths: list[str] = []
    for entry in entries:
        require(isinstance(entry, dict)
                and set(entry) == {"path", "bytes", "sha256"},
                "malformed payload-manifest entry")
        rel = checked_relative(entry["path"])
        require(rel not in {"payload-manifest.json", "verify_monotonicity.py"},
                f"self-referential payload entry: {rel}")
        require(isinstance(entry["bytes"], int) and entry["bytes"] >= 0,
                f"bad byte count: {rel}")
        require(isinstance(entry["sha256"], str)
                and HEX64.fullmatch(entry["sha256"]), f"bad SHA-256: {rel}")
        path = ROOT / rel
        require(path.is_file(), f"payload file missing: {rel}")
        require(path.stat().st_size == entry["bytes"], f"byte mismatch: {rel}")
        require(sha256(path) == entry["sha256"], f"digest mismatch: {rel}")
        paths.append(rel)
    require(paths == sorted(paths) and len(paths) == len(set(paths)),
            "payload paths must be sorted and unique")
    files, _ = scan_tree(ROOT)
    require(files == set(paths) | {"payload-manifest.json", "verify_monotonicity.py"},
            "payload tree differs from manifest")
    for rel, expected in EXPECTED_HASHES.items():
        require(sha256(ROOT / rel) == expected, f"critical digest mismatch: {rel}")


def verify_raw_inventory() -> dict[str, dict[str, object]]:
    data = load_json(RAW_INVENTORY)
    require(isinstance(data, dict)
            and set(data) == {"schema_version", "root", "files"}
            and data["schema_version"] == 1 and data["root"] == "raw",
            "unsupported raw inventory")
    entries = data["files"]
    require(isinstance(entries, list) and entries, "empty raw inventory")
    indexed: dict[str, dict[str, object]] = {}
    paths: list[str] = []
    for entry in entries:
        require(isinstance(entry, dict)
                and set(entry) == {"path", "bytes", "sha256", "mode", "mtime_ns"},
                "malformed raw-inventory entry")
        rel = checked_relative(entry["path"])
        require(rel.startswith(("focused/", "full-class/")),
                f"raw path outside run trees: {rel}")
        require(isinstance(entry["bytes"], int) and entry["bytes"] >= 0,
                f"bad raw byte count: {rel}")
        require(isinstance(entry["sha256"], str)
                and HEX64.fullmatch(entry["sha256"]), f"bad raw digest: {rel}")
        require(isinstance(entry["mode"], str)
                and re.fullmatch(r"0[0-7]{3}", entry["mode"]), f"bad raw mode: {rel}")
        require(isinstance(entry["mtime_ns"], int) and entry["mtime_ns"] >= 0,
                f"bad raw mtime: {rel}")
        path = RAW / rel
        info = path.stat(follow_symlinks=False)
        require(stat.S_ISREG(info.st_mode), f"raw file missing: {rel}")
        require(info.st_size == entry["bytes"], f"raw byte mismatch: {rel}")
        require(sha256(path) == entry["sha256"], f"raw digest mismatch: {rel}")
        require(f"0{stat.S_IMODE(info.st_mode):03o}" == entry["mode"],
                f"raw mode mismatch: {rel}")
        require(info.st_mtime_ns == entry["mtime_ns"], f"raw mtime mismatch: {rel}")
        paths.append(rel)
        indexed[rel] = entry
    require(paths == sorted(paths) and len(paths) == len(set(paths)),
            "raw paths must be sorted and unique")
    files, _ = scan_tree(RAW)
    require(files == set(paths), "raw tree differs from raw inventory")
    require(len(paths) == 43, f"expected 43 raw files, found {len(paths)}")
    return indexed


def verify_archive(archive: Path, root_name: str,
                   inventory: dict[str, dict[str, object]]) -> None:
    expected = {path: entry for path, entry in inventory.items()
                if path.startswith(root_name + "/")}
    seen: dict[str, tuple[int, str]] = {}
    names: list[str] = []
    with tarfile.open(archive, "r:gz") as bundle:
        for member in bundle:
            rel = checked_relative(member.name.rstrip("/"))
            require(rel == root_name or rel.startswith(root_name + "/"),
                    f"archive member outside {root_name}: {rel}")
            require(member.uid == 0 and member.gid == 0,
                    f"archive ownership not normalized: {rel}")
            require(member.mtime == 0, f"archive mtime not normalized: {rel}")
            require(not (member.issym() or member.islnk()), f"archive link forbidden: {rel}")
            if member.isdir():
                names.append(rel + "/")
                continue
            require(member.isreg(), f"non-regular archive member: {rel}")
            stream = bundle.extractfile(member)
            require(stream is not None, f"cannot read archive member: {rel}")
            digest = hashlib.sha256()
            size = 0
            for block in iter(lambda: stream.read(1024 * 1024), b""):
                digest.update(block)
                size += len(block)
            seen[rel] = (size, digest.hexdigest())
            names.append(rel)
            raw_entry = expected.get(rel)
            require(raw_entry is not None, f"unexpected archive file: {rel}")
            require(size == raw_entry["bytes"] and digest.hexdigest() == raw_entry["sha256"],
                    f"archive content differs from raw file: {rel}")
            require(f"0{member.mode:03o}" == raw_entry["mode"],
                    f"archive mode differs from raw file: {rel}")
    require(seen.keys() == expected.keys(), f"archive inventory mismatch: {root_name}")
    require(names == sorted(names), f"archive members not sorted: {root_name}")


def apply_additive_patch(original: bytes, patch: bytes) -> bytes:
    source = original.decode("utf-8").splitlines(keepends=True)
    lines = patch.decode("utf-8").splitlines(keepends=True)
    require(sum(line.startswith("diff --git ") for line in lines) == 1,
            "diff must touch exactly one file")
    require(lines[0].rstrip().endswith(
        "a/services/tests/mockingservicestests/src/com/android/server/job/"
        "controllers/JobStatusTest.java "
        "b/services/tests/mockingservicestests/src/com/android/server/job/"
        "controllers/JobStatusTest.java"), "diff targets the wrong file")
    hunks: list[tuple[int, list[str]]] = []
    index = 0
    while index < len(lines):
        match = re.match(r"@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@", lines[index])
        if not match:
            index += 1
            continue
        body: list[str] = []
        old_start = int(match.group(1))
        index += 1
        while index < len(lines) and not lines[index].startswith("@@ "):
            line = lines[index]
            require(line.startswith((" ", "+", "-", "\\ No newline")),
                    "unsupported unified-diff line")
            if line.startswith("\\ No newline"):
                index += 1
                continue
            require(not line.startswith("-"), "test-only diff must not delete lines")
            body.append(line)
            index += 1
        hunks.append((old_start, body))
    require(len(hunks) == 2, f"expected two additive hunks, found {len(hunks)}")
    require(sum(line.startswith("+") for _, body in hunks for line in body) == 147,
            "diff does not contain exactly 147 insertions")
    output: list[str] = []
    cursor = 0
    for old_start, body in hunks:
        target = old_start - 1
        require(target >= cursor, "overlapping diff hunks")
        output.extend(source[cursor:target])
        cursor = target
        for line in body:
            if line.startswith(" "):
                require(cursor < len(source) and source[cursor] == line[1:],
                        f"diff context mismatch at source line {cursor + 1}")
                output.append(line[1:])
                cursor += 1
            else:
                output.append(line[1:])
    output.extend(source[cursor:])
    return "".join(output).encode("utf-8")


def method_header(source: str, method: str) -> str:
    match = re.search(r"\bpublic\s+void\s+" + re.escape(method) + r"\s*\(", source)
    require(match is not None, f"method missing from source: {method}")
    # Java annotation arguments themselves contain closing braces, so the
    # previous source-level `}` is not a safe boundary. All relevant decorators
    # are immediately adjacent and fit comfortably in this bounded window.
    return source[max(0, match.start() - 500):match.start()]


def verify_source() -> tuple[set[str], set[str]]:
    pristine_bytes = PRISTINE_TEST.read_bytes()
    monotonic_bytes = MONOTONIC_TEST.read_bytes()
    reconstructed = apply_additive_patch(pristine_bytes, PATCH.read_bytes())
    require(reconstructed == monotonic_bytes, "diff reconstruction does not match source")
    pristine_text = pristine_bytes.decode("utf-8")
    monotonic_text = monotonic_bytes.decode("utf-8")
    pristine = set(TEST_RE.findall(pristine_text))
    monotonic = set(TEST_RE.findall(monotonic_text))
    require(len(pristine) == 71 and len(monotonic) == 72,
            f"unexpected source test counts: {len(pristine)}, {len(monotonic)}")
    require(monotonic - pristine == {EXPECTED_METHOD} and pristine < monotonic,
            "variant does not add exactly the monotonicity method")

    new_header = method_header(monotonic_text, EXPECTED_METHOD)
    require("@Test" in new_header, "new method lacks @Test")
    require("@EnableFlags" not in new_header and "@DisableFlags" not in new_header,
            "new method unexpectedly has a flag annotation")
    for method in EXPECTED_SKIPS:
        header = method_header(pristine_text, method)
        require("@EnableFlags" in header
                and "FLAG_ENHANCED_PENDING_AND_STOP_REASONS_API" in header,
                f"pre-existing assumption method lacks enhanced-flag annotation: {method}")

    for snippet in (
        "createRestrictedAppStandbyJobForMonotonicity",
        "assertFalse(job.isReady());",
        "Arrays.stream(job.getPendingJobReasons(null))",
        "job.getPendingJobReasonStats()",
        "assertTrue(\"a cumulative lifetime total decreased without a reset\", later < earlier)",
    ):
        require(snippet in monotonic_text, f"monotonicity premise missing: {snippet}")

    require(BASELINE_JOB_STATUS.read_bytes() == MONOTONIC_JOB_STATUS.read_bytes(),
            "production JobStatus differs across variants")
    job_status_text = BASELINE_JOB_STATUS.read_text(encoding="utf-8")
    single_mapping_start = job_status_text.index(
        "if (hasConstraintFlag(constraint, CONSTRAINT_BATTERY_NOT_LOW))")
    single_mapping_end = job_status_text.index(
        "if (hasConstraintFlag(constraint, CONSTRAINT_CONNECTIVITY))",
        single_mapping_start)
    single_mapping = job_status_text[single_mapping_start:single_mapping_end]
    require(single_mapping.count("PENDING_JOB_REASON_APP_STANDBY") == 3
            and "Flags." not in single_mapping,
            "focal single-constraint APP_STANDBY mappings are flag-guarded or incomplete")
    list_mapping_start = job_status_text.index(
        "if (hasConstraintFlag(unsatisfiedConstraints, CONSTRAINT_BATTERY_NOT_LOW))")
    list_mapping_end = job_status_text.index(
        "if (hasConstraintFlag(unsatisfiedConstraints, CONSTRAINT_CONNECTIVITY))",
        list_mapping_start)
    list_mapping = job_status_text[list_mapping_start:list_mapping_end]
    require(list_mapping.count("PENDING_JOB_REASON_APP_STANDBY") >= 3
            and "Flags." not in list_mapping,
            "focal current-reason APP_STANDBY mappings are flag-guarded or incomplete")
    updater_start = job_status_text.index("private void updatePendingJobReasonStats(")
    updater_end = job_status_text.index("public Map<String, ParcelDuration> "
                                        "getPendingJobReasonStats()", updater_start)
    getter_end = job_status_text.index("public boolean isConstraintSatisfied(", updater_end)
    require("Flags." not in job_status_text[updater_start:updater_end],
            "duration updater unexpectedly has a flag guard")
    require("Flags." not in job_status_text[updater_end:getter_end],
            "duration getter unexpectedly has a flag guard")
    mocking_bp = MOCKING_BP.read_text(encoding="utf-8")
    service_bp = SERVICE_BP.read_text(encoding="utf-8")
    require('name: "FrameworksMockingServicesTests"' in mocking_bp
            and '"service-jobscheduler"' in mocking_bp,
            "test module does not show service-jobscheduler static linkage")
    require('name: "service-jobscheduler"' in service_bp
            and '"java/**/*.java"' in service_bp,
            "production module does not show Java source inclusion")

    metadata = load_json(SOURCE_METADATA)
    require(isinstance(metadata, dict), "source metadata is not an object")
    baseline = metadata.get("baseline")
    commit = metadata.get("preservation_commit")
    require(isinstance(baseline, dict) and baseline.get("revision") == EXPECTED_REVISION,
            "baseline revision mismatch")
    require(isinstance(commit, dict) and commit.get("revision") == EXPECTED_COMMIT
            and commit.get("parent") == EXPECTED_REVISION
            and commit.get("tree") == EXPECTED_TREE
            and commit.get("postdates_execution") is True,
            "preservation-commit metadata mismatch")
    changed = commit.get("changed_paths")
    require(changed == [{
        "status": "M",
        "path": "services/tests/mockingservicestests/src/com/android/server/job/"
                "controllers/JobStatusTest.java",
        "insertions": 147,
        "deletions": 0,
    }], "changed-path metadata mismatch")
    binding = metadata.get("execution_binding")
    require(isinstance(binding, dict) and binding.get("status") == "post_hoc"
            and binding.get("apk_archived") is False
            and binding.get("raw_logs_contain_git_revision") is False
            and binding.get("raw_logs_contain_test_source_digest") is False,
            "source-binding caveat missing")
    return pristine, monotonic


def collect_outcomes(path: Path) -> dict[str, set[str]]:
    data = load_json(path)
    found: dict[str, list[str]] = {
        "PASSED": [], "FAILED": [], "IGNORED": [], "ASSUMPTION_FAILED": []
    }

    def visit(value: object) -> None:
        if isinstance(value, dict):
            for key, records in value.items():
                if key in found and isinstance(records, list):
                    for record in records:
                        require(isinstance(record, dict)
                                and isinstance(record.get("test_name"), str),
                                f"malformed {key} record in {path.relative_to(ROOT)}")
                        found[key].append(record["test_name"])
                elif key != "total_summary":
                    visit(records)
        elif isinstance(value, list):
            for child in value:
                visit(child)

    visit(data)
    all_names = [name for values in found.values() for name in values]
    require(len(all_names) == len(set(all_names)),
            f"duplicate or cross-outcome record in {path.relative_to(ROOT)}")
    require(all(name.startswith(EXPECTED_CLASS + "#") for name in all_names),
            f"outcome outside JobStatusTest in {path.relative_to(ROOT)}")
    return {key: {name.split("#", 1)[1] for name in values}
            for key, values in found.items()}


def verify_results(monotonic_methods: set[str]) -> None:
    focused = collect_outcomes(FOCUSED_RESULT)
    require(focused == {
        "PASSED": {EXPECTED_METHOD}, "FAILED": set(), "IGNORED": set(),
        "ASSUMPTION_FAILED": set(),
    }, "focused outcome mismatch")
    full = collect_outcomes(FULL_RESULT)
    require(len(full["PASSED"]) == 68 and not full["FAILED"] and not full["IGNORED"]
            and full["ASSUMPTION_FAILED"] == EXPECTED_SKIPS,
            "full-class outcome mismatch")
    require(full["PASSED"] | full["ASSUMPTION_FAILED"] == monotonic_methods,
            "full-class outcomes do not cover the 72 source methods")
    require(EXPECTED_METHOD in full["PASSED"], "new method did not pass full class")

    focused_log = FOCUSED_LOG.read_text(encoding="utf-8", errors="replace")
    full_log = FULL_LOG.read_text(encoding="utf-8", errors="replace")
    require("Passed\x1b[0m: 1, Failed: 0, Ignored: 0, Assumption Failed: 0"
            in focused_log, "focused Atest summary missing")
    require("0 APK(s) skipped installation." in focused_log
            and "1 APK(s) did not skip installation." in focused_log,
            "focused install relationship missing")
    require("Passed\x1b[0m: 68, Failed: 0, Ignored: 0, Assumption Failed: 4"
            in full_log, "full Atest summary missing")
    require("1 APK(s) skipped installation." in full_log
            and "0 APK(s) did not skip installation." in full_log,
            "full-class incremental reuse relationship missing")
    for method in EXPECTED_SKIPS:
        require(any(method in line and ASSUMPTION_PHRASE in line
                    for line in full_log.splitlines()),
                f"assumption trace/reason missing: {method}")

    focused_host = FOCUSED_HOST.read_text(encoding="utf-8", errors="replace")
    full_host = FULL_HOST.read_text(encoding="utf-8", errors="replace")
    device_log = FULL_DEVICE.read_text(encoding="utf-8", errors="replace")
    require("Installing apk com.android.frameworks.mockingservicestests" in focused_host,
            "focused host log lacks APK installation")
    require(EXPECTED_APK_CACHE_DIGEST in full_host
            and "Skipping the installation of com.android.frameworks.mockingservicestests"
            in full_host, "full host log lacks cached APK digest/reuse")
    require("ro.build.id=CP31.260618.005" in full_host,
            "full host log lacks CP31 build ID")
    require(EXPECTED_FINGERPRINT in device_log, "device fingerprint missing")

    execution = load_json(EXECUTION)
    result = load_json(RESULT)
    require(isinstance(execution, dict) and isinstance(result, dict),
            "structured execution/result is malformed")
    require(execution.get("source_binding", {}).get("status") == "post_hoc",
            "execution record omits post-hoc binding")
    run_time = datetime.fromisoformat(execution["runs"]["full_class"]["finished_local"])
    commit_time = datetime.fromisoformat(
        execution["source_binding"]["preservation_commit_created_local"])
    require(commit_time > run_time, "preservation commit does not postdate execution")
    require(result.get("fixture_scope", {}).get("registered_in_job_store") is False
            and result.get("fixture_scope", {}).get("binder_or_public_api") is False,
            "fixture/public-membership limitation missing")
    require(result.get("flag_scope", {}).get("added_method_annotation") == "none"
            and result.get("flag_scope", {}).get("executed_flag_states")
            == "target default only", "flag limitation missing")


def verify_scan_and_apk_absence() -> None:
    scan = load_json(SCAN_REPORT)
    require(isinstance(scan, dict) and scan.get("high_confidence_secret_found") is False,
            "scan report does not record secret-review outcome")
    limitations = scan.get("limitations")
    require(isinstance(limitations, list)
            and any("final human release review" in item for item in limitations),
            "scan report omits public-release caution")
    files, _ = scan_tree(ROOT)
    require(not any(path.lower().endswith(".apk") for path in files),
            "unexpected APK present; metadata must be reevaluated")


def main() -> None:
    try:
        verify_payload_manifest()
        inventory = verify_raw_inventory()
        verify_archive(ROOT / "archives/focused-atest-result.tar.gz",
                       "focused", inventory)
        verify_archive(ROOT / "archives/full-class-atest-result.tar.gz",
                       "full-class", inventory)
        _, monotonic_methods = verify_source()
        verify_results(monotonic_methods)
        verify_scan_and_apk_absence()
    except VerificationError as exc:
        raise SystemExit(f"FAIL: {exc}") from exc
    print("PASS: CP31 monotonicity evidence is internally consistent")
    print("  focused: 1 passed; 0 failed/ignored/assumption")
    print("  full class: 68 passed; 0 failed/ignored; 4 pre-existing assumptions")
    print("  source: 71 upstream + 1 test-only addition; production JobStatus unchanged")
    print("  provenance: source binding is explicitly post hoc; APK is not archived")


if __name__ == "__main__":
    main()

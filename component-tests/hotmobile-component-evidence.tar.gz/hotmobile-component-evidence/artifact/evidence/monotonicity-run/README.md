# CP31 monotonicity component-test evidence

This directory preserves the two final Atest result trees for the single
monotonicity characterization added to AOSP's `JobStatusTest`:

- `raw/focused/` is the one-method run: 1 passed, with no failures, ignores,
  or assumption failures.
- `raw/full-class/` is the complete-class run: 68 passed, no failures or
  ignores, and four pre-existing flag-conditioned methods skipped by JUnit
  assumptions. The new monotonicity method is one of the 68 passes.

The byte-for-byte copies retain the raw Atest logs and their original metadata.
The two archives contain the same trees with sorted members, normalized archive
ownership and timestamps, and `gzip -n` headers. `raw-inventory.json` binds
every raw regular file, including its byte count, mode, nanosecond mtime, and
SHA-256. `payload-manifest.json` binds the complete evidence payload.

## Provenance boundary

The production baseline is `frameworks/base` revision
`94b4c163b7dfe5ce3607f7bb8456f9573f7de57d` (`android-17.0.0_r1`). The
test-only preservation commit
`27c982edb84426f94ed569ac782c0a0991ebe362` has that revision as its parent and
changes only `JobStatusTest.java`; both revisions contain byte-identical
production `JobStatus.java`.

That preservation commit was created after the executions. The Atest records
prove that a freshly built APK containing the named method ran and produced the
recorded outcomes, while the retained source was independently observed
unchanged after the run and then committed. The raw logs do **not** record the
Git revision or a test-source digest, and the APK is no longer available. The
source-to-execution binding is therefore post hoc, not a contemporaneous signed
or digest-bound build record. The Tradefed incremental-setup digest retained in
the full-class host log is evidence about the installed/cached APK relationship,
not a substitute for the missing APK.

`r1-baseline-repo-manifest.xml` is a baseline r1 reference copied from the
already sealed CP2A evidence. It is not represented as a manifest captured by
either CP31 run.

## Scope limits

The added method directly constructs two local, unregistered `JobStatus`
records, drives internal constraint transitions with `TestClock`, and queries
the internal duration map. It does not traverse `JobStore`, Binder, an app UID,
or the public API. Its `isReady() == false` checks establish component-record
ineligibility, not public pending-job membership. The method has no flag
annotation and therefore ran under the target default; it does not execute both
flag states. Source inspection shows that the focal `APP_STANDBY` mappings,
updater, and getter are not guarded by the enhanced-reasons flag.

This is a separate 71-upstream-plus-one-test variant. It must not be pooled with
the sealed 71-plus-16 CP2A variant as though a 17-addition complete-class run
occurred.

## Verification and release caution

From this directory, run:

```sh
python3 -I verify_monotonicity.py
```

The verifier uses only Python's standard library. It validates the inventories,
archives, source reconstruction, test counts and annotations, raw outcomes,
assumption names/reason, build fingerprint, and focused-install/full-reuse log
relationship.

The raw records are intentionally unredacted. `scan-report.json` records the
targeted credential/PII review. It found no credential-shaped secret but did
find the local account/path string `upgautam`, Atest/emulator identifiers, and
ordinary emulator-network data. Review that report before any public commit or
release. The original `/tmp` trees were not moved or deleted.

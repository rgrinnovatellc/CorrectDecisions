# HotMobile 2027 scope boundary

This directory is the self-contained workspace for the six-page HotMobile 2027
paper. `SCOPE.md` and `artifact/scope.json` are normative.

- Audit claims using files inside this directory only. The paper build may
  download only the digest-pinned ACM template files named in `Makefile`.
- Do not import claims, experiments, code, evidence, or TODOs from sibling
  `probe/`, `evidence/`, `paper/`, or `doc/` directories.
- The Android probe app and repository-wide device experiments belong to a
  longer study. They are not this paper's implementation or evaluation.
- The active executable artifact is the seven-test patch under
  `artifact/tests/`. Its fresh run contains 71 upstream tests plus those seven
  paper tests: 78 passed.
- `artifact/evidence/historical-run/` is a digest-bound archive that
  substantiates the manuscript's original 16-added/87-passed method claim. It
  is not permission to promote unreported outcomes into additional HotMobile
  findings.
- `artifact/evidence/historical-count/` is only a compact projection of that
  digest-bound archive.
- The evaluation executes direct AOSP `JobStatusTest` component tests. It does
  not execute the app-facing API or production controller routes, measure
  practical prevalence, or implement/evaluate the repair sketch.
- Only the paper's implementation and evaluation claims mapped in
  `artifact/CLAIMS.md` are supported by this artifact; cited background and
  related-work claims rely on their cited sources.
- Preserve the six-page workshop scope. Available evidence elsewhere in the
  repository is not permission to expand the paper.

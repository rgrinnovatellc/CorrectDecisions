#!/usr/bin/env python3
"""Create a name-hash projection from an atest JSON result.

This release-maintenance tool lets the artifact preserve historical pass-set
membership and counts without publishing names of tests outside paper scope.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    raw = args.input.read_bytes()
    data = json.loads(raw)
    names: list[str] = []

    def visit(value: object) -> None:
        if isinstance(value, dict):
            passed = value.get("PASSED")
            if isinstance(passed, list):
                for record in passed:
                    if not isinstance(record, dict) or not isinstance(record.get("test_name"), str):
                        raise SystemExit("malformed PASSED record")
                    names.append(record["test_name"])
            for key, child in value.items():
                if key != "PASSED":
                    visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)

    visit(data)
    if len(names) != len(set(names)):
        raise SystemExit("duplicate historical test name")
    output = {
        "schema_version": 1,
        "projection": "sha256 of each UTF-8 fully qualified PASSED test_name",
        "source_test_result_sha256": hashlib.sha256(raw).hexdigest(),
        "passed_name_sha256": sorted(hashlib.sha256(name.encode("utf-8")).hexdigest()
                                     for name in names),
    }
    args.output.write_text(json.dumps(output, indent=2, sort_keys=True) + "\n",
                           encoding="utf-8")


if __name__ == "__main__":
    main()

#!/usr/bin/env python3
"""Generate the paper-scoped, line-numbered AOSP source excerpts.

This release-maintenance tool reads an explicitly supplied AOSP checkout. It is
not used by the offline artifact verifier. Each output line begins with its
one-based upstream line number so a reader can relate the excerpt directly to
the source citations in the paper.
"""

from __future__ import annotations

import argparse
import hashlib
import json
from pathlib import Path


SPECS = (
    {
        "artifact_path": "JobStatus.java.txt",
        "project": "frameworks/base",
        "upstream_path": "apex/jobscheduler/service/java/com/android/server/job/controllers/JobStatus.java",
        "ranges": [[140, 164], [254, 263], [467, 476], [649, 658], [690, 704],
                   [846, 892], [1603, 1610], [1884, 1902], [1949, 1955],
                   [2133, 2140], [2168, 2170], [2183, 2219], [2261, 2315],
                   [2397, 2589], [2680, 2758], [2801, 2838], [2852, 2854],
                   [2929, 2946]],
        "full_sha256": "2a8fbe2a30f1967d677ebc9303446bd6833cb280bab11f3190a2bdb87450e7ba",
    },
    {
        "artifact_path": "JobInfo.java.txt",
        "project": "frameworks/base",
        "upstream_path": "apex/jobscheduler/framework/java/android/app/job/JobInfo.java",
        "ranges": [[437, 450]],
        "full_sha256": "e516143f6b1befee025670defe1e5579d5e13cc1e8aabf36cce29e5ef4aba69b",
    },
    {
        "artifact_path": "JobScheduler.java.txt",
        "project": "frameworks/base",
        "upstream_path": "apex/jobscheduler/framework/java/android/app/job/JobScheduler.java",
        "ranges": [[143, 182], [197, 201], [223, 270], [551, 584]],
        "full_sha256": "e107412eebaf7d3a97916fc01fb931e37a4f4668ce32d2e6fcef51652b91aa74",
    },
    {
        "artifact_path": "job.aconfig.txt",
        "project": "frameworks/base",
        "upstream_path": "apex/jobscheduler/framework/aconfig/job.aconfig",
        "ranges": [[51, 64]],
        "full_sha256": "51f540422e7bd45ea40c5d34d975f53621e1535622ff6ff92e063801d0064a30",
    },
    {
        "artifact_path": "get_pending_job_reason_stats_api_flag_values.textproto.txt",
        "project": "build/release",
        "upstream_path": "aconfig/cp2a/android.app.job/get_pending_job_reason_stats_api_flag_values.textproto",
        "ranges": [[1, 6]],
        "full_sha256": "2046d376322468d26d53881775bebf99bb880624d9fde9ee6a414c6ada146b1d",
    },
    {
        "artifact_path": "api37-JobScheduler-signature.txt",
        "project": "prebuilts/sdk",
        "upstream_path": "37.0/public/api/android.txt",
        "ranges": [[12039, 12053]],
        "full_sha256": "120e49c34fb809f007d433d20c13de9a374c969d5a87792f2336931956581933",
    },
    {
        "artifact_path": "api37-finalized-flag.txt",
        "project": "prebuilts/sdk",
        "upstream_path": "37.0/finalized-flags.txt",
        "ranges": [[54, 58]],
        "full_sha256": "22aa19ca7f5119411e46986cfde9e0ae777954566a19c8f0b733a42d91e0f6c2",
    },
    {
        "artifact_path": "JobSchedulerImpl.java.txt",
        "project": "frameworks/base",
        "upstream_path": "apex/jobscheduler/framework/java/android/app/JobSchedulerImpl.java",
        "ranges": [[42, 66], [199, 216]],
        "full_sha256": "9c122ee09fcab444048023ab9a6b3e7ef37c4635c5a0c059739c2e944800383e",
    },
    {
        "artifact_path": "IJobScheduler.aidl.txt",
        "project": "frameworks/base",
        "upstream_path": "apex/jobscheduler/framework/java/android/app/job/IJobScheduler.aidl",
        "ranges": [[25, 49]],
        "full_sha256": "ff0b5073028e212f29195af3421817705cca63ccfce6884d97b939f5819a3150",
    },
    {
        "artifact_path": "JobSchedulerService.java.txt",
        "project": "frameworks/base",
        "upstream_path": "apex/jobscheduler/service/java/com/android/server/job/JobSchedulerService.java",
        "ranges": [[2280, 2303], [4633, 4683], [4705, 4718], [4751, 4852],
                   [5546, 5557], [5946, 5964]],
        "full_sha256": "2344762463a3162caa09f6e005ae830b3b1813e402758aee7988488f05d60a35",
    },
    {
        "artifact_path": "BatteryController.java.txt",
        "project": "frameworks/base",
        "upstream_path": "apex/jobscheduler/service/java/com/android/server/job/controllers/BatteryController.java",
        "ranges": [[48, 54], [74, 122], [159, 215]],
        "full_sha256": "8766a1113f88fbb71c6652308c55a04db686f183440aaff962119199d918b1d6",
    },
    {
        "artifact_path": "BatteryService.java.txt",
        "project": "frameworks/base",
        "upstream_path": "services/core/java/com/android/server/BatteryService.java",
        "ranges": [[894, 965]],
        "full_sha256": "f6d15a8bd2c033eb0cbffdae9eee6bc332835b20f64cf71b027797e271b058a1",
    },
    {
        "artifact_path": "BatteryStatsImpl.java.txt",
        "project": "frameworks/base",
        "upstream_path": "services/core/java/com/android/server/power/stats/BatteryStatsImpl.java",
        "ranges": [[596, 613], [638, 647], [12944, 12959], [13433, 13448]],
        "full_sha256": "5cde1b5af2d8c5f738880bd9886f2855eb957a8256e97b38bfa310c1c2f0434c",
    },
)

REVISIONS = {
    "frameworks/base": "94b4c163b7dfe5ce3607f7bb8456f9573f7de57d",
    "build/release": "c85f4aebe46714235599a9bd6430a0fe30c6e8d5",
    "prebuilts/sdk": "0f07e8d60ab0aba46129e427101f96ba459a95c1",
}


def digest(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--aosp", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    args = parser.parse_args()
    args.output.mkdir(parents=True, exist_ok=True)

    entries = []
    for spec in SPECS:
        source = args.aosp / spec["project"] / spec["upstream_path"]
        raw = source.read_bytes()
        if digest(raw) != spec["full_sha256"]:
            raise SystemExit(f"unexpected upstream digest: {source}")
        lines = raw.decode("utf-8").splitlines()
        chunks = []
        for start, end in spec["ranges"]:
            if not (1 <= start <= end <= len(lines)):
                raise SystemExit(f"range {start}-{end} outside {source}")
            chunks.append(f"===== upstream lines {start}-{end} =====\n")
            chunks.extend(f"{number:06d}: {lines[number - 1]}\n"
                          for number in range(start, end + 1))
        output = "".join(chunks).encode("utf-8")
        target = args.output / spec["artifact_path"]
        target.write_bytes(output)
        entries.append({
            **spec,
            "project_revision": REVISIONS[spec["project"]],
            "full_bytes": len(raw),
            "excerpt_bytes": len(output),
            "excerpt_sha256": digest(output),
        })

    manifest = {
        "schema_version": 1,
        "aosp_tag": "android-17.0.0_r1",
        "projects": REVISIONS,
        "format": "one-based inclusive ranges; each emitted source line is prefixed by its upstream line number",
        "files": entries,
    }
    (args.output.parent / "MANIFEST.json").write_text(
        json.dumps(manifest, indent=2, sort_keys=True) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()

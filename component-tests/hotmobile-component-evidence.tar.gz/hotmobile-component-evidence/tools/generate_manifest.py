#!/usr/bin/env python3
"""Regenerate the HotMobile package manifest after an intentional release edit."""

from __future__ import annotations

import hashlib
import json
import os
import stat
from pathlib import Path


ROOT = Path(__file__).resolve().parents[1]
TARGET = ROOT / "artifact-manifest.json"
EXPECTED_FILES = {
    ".gitattributes", ".gitignore", "AGENTS.md", "Makefile", "README.md",
    "SCOPE.md", "hotmobile2027.tex", "references.bib", "supplemental.md",
    "verify_artifact.py",
    "artifact/CLAIMS.md", "artifact/LICENSES/README.md",
    "artifact/LICENSES/frameworks-base-NOTICE",
    "artifact/LICENSES/prebuilts-sdk-NOTICE", "artifact/PROVENANCE.md",
    "artifact/README.md", "artifact/REPRODUCE.md",
    "artifact/evidence/historical-count/README.md",
    "artifact/evidence/historical-count/archive-commitments.json",
    "artifact/evidence/historical-count/passed-name-hashes.json",
    "artifact/evidence/historical-run/README.md",
    "artifact/evidence/historical-run/sealed-16-test-run.tar.gz",
    "artifact/evidence/scoped-run/JobStatusTest.executed.java",
    "artifact/evidence/scoped-run/atest.log",
    "artifact/evidence/scoped-run/device-logcat.txt",
    "artifact/evidence/scoped-run/execution.json",
    "artifact/evidence/scoped-run/frameworks-base-status.txt",
    "artifact/evidence/scoped-run/relevant-revisions.json",
    "artifact/evidence/scoped-run/result.json",
    "artifact/evidence/scoped-run/test-result.json", "artifact/scope.json",
    "artifact/source/MANIFEST.json",
    "artifact/source/excerpts/BatteryController.java.txt",
    "artifact/source/excerpts/BatteryService.java.txt",
    "artifact/source/excerpts/BatteryStatsImpl.java.txt",
    "artifact/source/excerpts/IJobScheduler.aidl.txt",
    "artifact/source/excerpts/JobInfo.java.txt",
    "artifact/source/excerpts/JobScheduler.java.txt",
    "artifact/source/excerpts/JobSchedulerImpl.java.txt",
    "artifact/source/excerpts/JobSchedulerService.java.txt",
    "artifact/source/excerpts/JobStatus.java.txt",
    "artifact/source/excerpts/api37-JobScheduler-signature.txt",
    "artifact/source/excerpts/api37-finalized-flag.txt",
    "artifact/source/excerpts/get_pending_job_reason_stats_api_flag_values.textproto.txt",
    "artifact/source/excerpts/job.aconfig.txt",
    "artifact/tests/0001-hotmobile-seven-result-tests.patch",
    "artifact/tests/JobStatusTest.pre-patch.java", "artifact/traces.json",
    "tools/extract_source_excerpts.py", "tools/generate_manifest.py",
    "tools/project_test_name_hashes.py",
}
EXPECTED_DIRS = {
    str(parent)
    for name in EXPECTED_FILES
    for parent in Path(name).parents
    if str(parent) != "."
}

MONOTONICITY_PREFIX = "artifact/evidence/monotonicity-run"
MONOTONICITY_PAYLOAD = ROOT / MONOTONICITY_PREFIX / "payload-manifest.json"


def monotonicity_declared_files() -> set[str]:
    try:
        data = json.loads(MONOTONICITY_PAYLOAD.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise SystemExit(f"cannot read monotonicity payload manifest: {exc}") from exc
    if not isinstance(data, dict) or set(data) != {"schema_version", "files"} \
            or data["schema_version"] != 1 or not isinstance(data["files"], list):
        raise SystemExit("unsupported monotonicity payload manifest")
    relative: list[str] = []
    for entry in data["files"]:
        if not isinstance(entry, dict) or set(entry) != {"path", "bytes", "sha256"}:
            raise SystemExit("invalid monotonicity payload entry")
        value = entry["path"]
        if not isinstance(value, str) or not value or "\\" in value:
            raise SystemExit(f"unsafe monotonicity payload path: {value!r}")
        path = Path(value)
        if path.is_absolute() or ".." in path.parts or "." in path.parts \
                or path.as_posix() != value:
            raise SystemExit(f"unsafe monotonicity payload path: {value!r}")
        relative.append(value)
    if relative != sorted(relative) or len(relative) != len(set(relative)):
        raise SystemExit("monotonicity payload paths must be unique and sorted")
    return ({f"{MONOTONICITY_PREFIX}/{path}" for path in relative}
            | {f"{MONOTONICITY_PREFIX}/payload-manifest.json",
               f"{MONOTONICITY_PREFIX}/verify_monotonicity.py"})


def main() -> None:
    expected_files = EXPECTED_FILES | monotonicity_declared_files()
    expected_dirs = {
        str(parent)
        for name in expected_files
        for parent in Path(name).parents
        if str(parent) != "."
    }
    files: list[dict[str, object]] = []
    seen: set[str] = set()
    seen_dirs: set[str] = set()
    for directory, dirnames, filenames in os.walk(ROOT, followlinks=False):
        directory_path = Path(directory)
        for name in [*dirnames, *filenames]:
            path = directory_path / name
            mode = path.lstat().st_mode
            if stat.S_ISLNK(mode):
                raise SystemExit(f"refusing symlink: {path.relative_to(ROOT)}")
        if directory_path == ROOT:
            dirnames[:] = [name for name in dirnames if name not in {"build", ".git"}]
        rel_directory = directory_path.relative_to(ROOT).as_posix()
        if rel_directory != ".":
            seen_dirs.add(rel_directory)
        for name in filenames:
            path = directory_path / name
            if directory_path == ROOT and name == ".git":
                continue
            rel = path.relative_to(ROOT).as_posix()
            if rel == "artifact-manifest.json" or rel.startswith("build/"):
                continue
            if rel not in expected_files:
                raise SystemExit(f"refusing undeclared release file: {rel}")
            raw = path.read_bytes()
            seen.add(rel)
            files.append({
                "path": rel,
                "bytes": len(raw),
                "sha256": hashlib.sha256(raw).hexdigest(),
            })
    if seen != expected_files:
        missing = sorted(expected_files - seen)
        raise SystemExit(f"release file missing: {missing}")
    if seen_dirs != expected_dirs:
        missing = sorted(expected_dirs - seen_dirs)
        extra = sorted(seen_dirs - expected_dirs)
        raise SystemExit(f"release directory mismatch: missing={missing}, extra={extra}")
    files.sort(key=lambda entry: entry["path"])
    TARGET.write_text(json.dumps({"schema_version": 2, "files": files},
                                 indent=2, sort_keys=True) + "\n", encoding="utf-8")


if __name__ == "__main__":
    main()

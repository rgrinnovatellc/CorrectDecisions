# Supplemental information

This supplement is limited to the six-page HotMobile paper. Run `python3 -I
verify_artifact.py` from this directory to check the machine-verifiable record.

## Focal component sequence

The following pseudocode describes the direct `JobStatus` component test. It is
not app-facing Android code. Times are synthetic `TestClock` units.
`AS` abbreviates `APP_STANDBY`.

```text
time = 0
job = JobStatus(jobInfoWithNoRequestedFocalConstraints)
job.enqueueTime = 0
job.enterRestrictedBucket()
job.reportChargingSatisfied(true)
job.reportBatteryNotLowSatisfied(true)
job.reportIdleSatisfied(true)

time = 10; job.reportChargingSatisfied(false);       query AS -> 0
time = 20; job.reportBatteryNotLowSatisfied(false);  query AS -> 0
time = 30; job.reportChargingSatisfied(true);        query AS -> 10
time = 40; job.reportBatteryNotLowSatisfied(true);   query AS -> 50
```

Charging contributes to `APP_STANDBY` over `[10,30)`, and battery-not-low
contributes over `[20,40)`.
Therefore union time is 30 and additive constraint-time is 40. Idle remains
satisfied after its time-zero initialization.

## Paper-result cases

- Removing intermediate queries still returns 50.
- Reversing which overlapping constraint becomes satisfied first still returns
  50.
- A single 30-unit charging interval returns 30, matching both references.
- Two nonoverlapping 10-unit intervals return 20, matching both references.
- Removing Restricted membership after 10 units of charging alone and five with
  both contributors returns an `APP_STANDBY` key with value zero.
- In the ranking trace, `JobStatus` returns 40 for `APP_STANDBY` and 25 for
  requested battery-not-low. Under either reference, requested battery-not-low
  (25) ranks above `APP_STANDBY` (20 additive; 15 union).

These results come from the fresh paper-scoped run: all 78 tests passed (71
upstream plus seven added). The manuscript's earlier 16-added/87-passed method
archive is preserved separately. The other nine tests substantiate only the
additional coverage families named in Method; their unreported outcomes are
not results in this supplement.

## Evidence boundary

The run directly executes `JobStatusTest`, not the public API or controller
stack. Source tracing connects the component map to the public query without
reaggregation and identifies controller routes capable of the two studied
closing orders. The artifact does not measure practical prevalence and does not
contain an implemented or evaluated repair.

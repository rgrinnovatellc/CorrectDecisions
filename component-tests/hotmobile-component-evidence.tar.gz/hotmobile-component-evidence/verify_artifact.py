#!/usr/bin/env python3
"""Verify the self-contained, paper-scoped HotMobile 2027 artifact.

The verifier uses only Python's standard library and reads no path outside this
directory. It establishes internal consistency and content integrity. The Git
commit or release-archive digest containing this verifier is the external trust
anchor for authorship/authenticity.
"""

from __future__ import annotations

import hashlib
import json
import os
import re
import stat
import subprocess
import sys
import tarfile
from datetime import datetime
from fractions import Fraction
from pathlib import Path, PurePosixPath


if sys.version_info < (3, 10):
    raise SystemExit("FAIL: Python 3.10 or newer is required")

ROOT = Path(__file__).resolve().parent
ARTIFACT = ROOT / "artifact"
MANIFEST = ROOT / "artifact-manifest.json"
SCOPE = ARTIFACT / "scope.json"
TRACES = ARTIFACT / "traces.json"
TESTS = ARTIFACT / "tests"
PATCH = TESTS / "0001-hotmobile-seven-result-tests.patch"
PRE_PATCH = TESTS / "JobStatusTest.pre-patch.java"
RUN = ARTIFACT / "evidence/scoped-run"
EXECUTION = RUN / "execution.json"
RESULT = RUN / "result.json"
TEST_RESULT = RUN / "test-result.json"
ATEST_LOG = RUN / "atest.log"
DEVICE_LOG = RUN / "device-logcat.txt"
EXECUTED_TEST = RUN / "JobStatusTest.executed.java"
STATUS = RUN / "frameworks-base-status.txt"
REVISIONS = RUN / "relevant-revisions.json"
HISTORICAL = ARTIFACT / "evidence/historical-count/archive-commitments.json"
HISTORICAL_NAMES = ARTIFACT / "evidence/historical-count/passed-name-hashes.json"
HISTORICAL_RUN = ARTIFACT / "evidence/historical-run"
HISTORICAL_ARCHIVE = HISTORICAL_RUN / "sealed-16-test-run.tar.gz"
MONOTONICITY_RUN = ARTIFACT / "evidence/monotonicity-run"
MONOTONICITY_PAYLOAD = MONOTONICITY_RUN / "payload-manifest.json"
MONOTONICITY_VERIFIER = MONOTONICITY_RUN / "verify_monotonicity.py"
SOURCE_MANIFEST = ARTIFACT / "source/MANIFEST.json"
EXCERPTS = ARTIFACT / "source/excerpts"

EXPECTED_ROOT_FILES = {
    ".gitattributes", ".gitignore", "AGENTS.md", "Makefile", "README.md",
    "SCOPE.md", "artifact-manifest.json", "hotmobile2027.tex", "references.bib",
    "supplemental.md", "verify_artifact.py",
}
EXPECTED_ROOT_DIRS = {"artifact", "build", "tools"}
EXPECTED_BUILD_FILES = {"hotmobile2027.pdf", "hotmobile2027.bbl", "hotmobile2027.log"}
EXPECTED_IMMUTABLE_FILES = {
    ".gitattributes", ".gitignore", "AGENTS.md", "Makefile", "README.md",
    "SCOPE.md", "hotmobile2027.tex", "references.bib", "supplemental.md",
    "verify_artifact.py",
    "artifact/CLAIMS.md", "artifact/LICENSES/README.md",
    "artifact/LICENSES/frameworks-base-NOTICE",
    "artifact/LICENSES/prebuilts-sdk-NOTICE", "artifact/PROVENANCE.md",
    "artifact/README.md", "artifact/REPRODUCE.md",
    "artifact/evidence/historical-count/README.md",
    "artifact/evidence/historical-count/archive-commitments.json",
    "artifact/evidence/historical-count/passed-name-hashes.json",
    "artifact/evidence/historical-run/README.md",
    "artifact/evidence/historical-run/sealed-16-test-run.tar.gz",
    "artifact/evidence/scoped-run/JobStatusTest.executed.java",
    "artifact/evidence/scoped-run/atest.log",
    "artifact/evidence/scoped-run/device-logcat.txt",
    "artifact/evidence/scoped-run/execution.json",
    "artifact/evidence/scoped-run/frameworks-base-status.txt",
    "artifact/evidence/scoped-run/relevant-revisions.json",
    "artifact/evidence/scoped-run/result.json",
    "artifact/evidence/scoped-run/test-result.json", "artifact/scope.json",
    "artifact/source/MANIFEST.json",
    "artifact/source/excerpts/BatteryController.java.txt",
    "artifact/source/excerpts/BatteryService.java.txt",
    "artifact/source/excerpts/BatteryStatsImpl.java.txt",
    "artifact/source/excerpts/IJobScheduler.aidl.txt",
    "artifact/source/excerpts/JobInfo.java.txt",
    "artifact/source/excerpts/JobScheduler.java.txt",
    "artifact/source/excerpts/JobSchedulerImpl.java.txt",
    "artifact/source/excerpts/JobSchedulerService.java.txt",
    "artifact/source/excerpts/JobStatus.java.txt",
    "artifact/source/excerpts/api37-JobScheduler-signature.txt",
    "artifact/source/excerpts/api37-finalized-flag.txt",
    "artifact/source/excerpts/get_pending_job_reason_stats_api_flag_values.textproto.txt",
    "artifact/source/excerpts/job.aconfig.txt",
    "artifact/tests/0001-hotmobile-seven-result-tests.patch",
    "artifact/tests/JobStatusTest.pre-patch.java", "artifact/traces.json",
    "tools/extract_source_excerpts.py", "tools/generate_manifest.py",
    "tools/project_test_name_hashes.py",
}
EXPECTED_IMMUTABLE_DIRS = {
    str(parent)
    for name in EXPECTED_IMMUTABLE_FILES
    for parent in PurePosixPath(name).parents
    if str(parent) != "."
}
EXPECTED_REVISION = "94b4c163b7dfe5ce3607f7bb8456f9573f7de57d"
EXPECTED_PROJECTS = {
    "frameworks/base": EXPECTED_REVISION,
    "build/release": "c85f4aebe46714235599a9bd6430a0fe30c6e8d5",
    "prebuilts/sdk": "0f07e8d60ab0aba46129e427101f96ba459a95c1",
}
EXPECTED_TARGET = "FrameworksMockingServicesTests_com_android_server_job"
EXPECTED_CLASS = "com.android.server.job.controllers.JobStatusTest"
EXPECTED_STATUS = (
    " M services/tests/mockingservicestests/src/com/android/server/job/"
    "controllers/JobStatusTest.java\n"
)
EXPECTED_CRITICAL_HASHES = {
    "patch": "bb49a744474ecbd96a2c322a7ce958b2ddf69fc14d81829dec8961334b50c6b8",
    "pre_patch": "6393bf27be4ae1baa7a0e4bbf7ae7bfbc1965cd4d97fa6456490eb6f577b8cbe",
    "executed_test": "f9d949299765cdf423c428660ba5d4f273d5ca7f416fbd36940fa784ea2cb8ab",
    "test_result": "00e798abd049e1c4d09601514787466052697c329065e8bc3640f56e855894cf",
    "atest_log": "2f33b8da0a9c36fefcdc6be6bfbdeb957e2a4cd80ebee0faeb7aae9dc631d6f6",
    "device_log": "e8f12ea1111abaf829aab051df571f93059ff4a643fafcdca1a6d158eee836e9",
    "status": "937517bbb564fc49cbed5e78457f1f3f7f37c118550b8d560611bf29072ea92d",
    "job_status": "2a8fbe2a30f1967d677ebc9303446bd6833cb280bab11f3190a2bdb87450e7ba",
    "scope": "d531798b32b5a51e42fc384cf00670a248a4ae826c80d0ca5c26d1d2b5871deb",
    "traces": "247d5322e6902381cd83c28fbbb27627e8c800a87893e1aa3eceff5e189baf2e",
    "source_manifest": "977ae95c0e711357ff62c8f3dcc2e3b11d15bb081d803cdceda9fdbecbf95c0d",
    "execution": "11703bc75e52a57ff0e1dc3a6b03222965e306697eacb6b2d5aabc5f497c0523",
    "result": "35c7a454095eb20cc93818eed166c046d5db23937573f0d6ed098ea999190805",
    "revisions": "f49b0a73a85f8ae1d14c84249830b9872222e349a170f67e2d51ef33696bd025",
    "historical": "f0991a4bcd9e1e4da3e1d3b59bcb751bf1dbaed09b6383841562c40f8b469191",
    "historical_names": "57c2d6ae02c8a60c304e3e951b095276b669ae5c073056144f9ca2f1afa0ea20",
}
EXPECTED_ROLES = {
    "execution_record": ("execution.json", "application/json"),
    "test_result": ("test-result.json", "application/json"),
    "atest_log": ("atest.log", "text/plain"),
    "device_logcat": ("device-logcat.txt", "text/plain"),
    "patched_test_source": ("JobStatusTest.executed.java", "text/x-java-source"),
    "frameworks_base_status": ("frameworks-base-status.txt", "text/plain"),
    "relevant_revisions": ("relevant-revisions.json", "application/json"),
}
EXPECTED_PAPER_TESTS = {
    "testPendingReasonStats_samePublicReasonChargingFirstCloseCharacterization",
    "testPendingReasonStats_samePublicReasonChargingFirstCloseQueryFreeCharacterization",
    "testPendingReasonStats_dynamicMembershipRemovalCharacterization",
    "testPendingReasonStats_samePublicReasonBatteryNotLowFirstCloseCharacterization",
    "testPendingReasonStats_samePublicReasonNonoverlapControl",
    "testPendingReasonStats_oneDynamicPredicateControl",
    "testPendingReasonStats_rankingReversalCharacterization",
}
EXPECTED_SCENARIOS = {
    "one_predicate_control",
    "ranking_reversal_standby",
    "ranking_reversal_requested",
    "overlap_charging_first_close_query_free",
    "overlap_charging_first_close",
    "nonoverlap_control",
    "membership_removal",
    "overlap_battery_not_low_first_close",
}
EXPECTED_TRACE_IDENTITIES = {
    "one_predicate_control":
        ("testPendingReasonStats_oneDynamicPredicateControl", "APP_STANDBY"),
    "nonoverlap_control":
        ("testPendingReasonStats_samePublicReasonNonoverlapControl", "APP_STANDBY"),
    "overlap_charging_first_close_query_free":
        ("testPendingReasonStats_samePublicReasonChargingFirstCloseQueryFreeCharacterization",
         "APP_STANDBY"),
    "overlap_charging_first_close":
        ("testPendingReasonStats_samePublicReasonChargingFirstCloseCharacterization",
         "APP_STANDBY"),
    "overlap_battery_not_low_first_close":
        ("testPendingReasonStats_samePublicReasonBatteryNotLowFirstCloseCharacterization",
         "APP_STANDBY"),
    "membership_removal":
        ("testPendingReasonStats_dynamicMembershipRemovalCharacterization", "APP_STANDBY"),
    "ranking_reversal_standby":
        ("testPendingReasonStats_rankingReversalCharacterization", "APP_STANDBY"),
    "ranking_reversal_requested":
        ("testPendingReasonStats_rankingReversalCharacterization",
         "CONSTRAINT_BATTERY_NOT_LOW"),
}
EXPECTED_TRACE_RECORDS = {
    "one_predicate_control": {
        "test": EXPECTED_TRACE_IDENTITIES["one_predicate_control"][0],
        "reason": "APP_STANDBY", "enqueue_time": 0, "query_time": 40,
        "intervals": {"charging": [[10, 40]]},
    },
    "nonoverlap_control": {
        "test": EXPECTED_TRACE_IDENTITIES["nonoverlap_control"][0],
        "reason": "APP_STANDBY", "enqueue_time": 0, "query_time": 40,
        "intervals": {"charging": [[10, 20]], "battery-not-low": [[30, 40]]},
    },
    "overlap_charging_first_close_query_free": {
        "test": EXPECTED_TRACE_IDENTITIES["overlap_charging_first_close_query_free"][0],
        "reason": "APP_STANDBY", "enqueue_time": 0, "query_time": 40,
        "intervals": {"charging": [[10, 30]], "battery-not-low": [[20, 40]]},
    },
    "overlap_charging_first_close": {
        "test": EXPECTED_TRACE_IDENTITIES["overlap_charging_first_close"][0],
        "reason": "APP_STANDBY", "enqueue_time": 0, "query_time": 40,
        "asserted_sequence": [0, 0, 10, 50],
        "intervals": {"charging": [[10, 30]], "battery-not-low": [[20, 40]]},
    },
    "overlap_battery_not_low_first_close": {
        "test": EXPECTED_TRACE_IDENTITIES["overlap_battery_not_low_first_close"][0],
        "reason": "APP_STANDBY", "enqueue_time": 0, "query_time": 40,
        "intervals": {"charging": [[10, 40]], "battery-not-low": [[20, 30]]},
    },
    "membership_removal": {
        "test": EXPECTED_TRACE_IDENTITIES["membership_removal"][0],
        "reason": "APP_STANDBY", "enqueue_time": 0, "query_time": 25,
        "intervals": {"charging": [[10, 25]], "battery-not-low": [[20, 25]]},
    },
    "ranking_reversal_standby": {
        "test": EXPECTED_TRACE_IDENTITIES["ranking_reversal_standby"][0],
        "reason": "APP_STANDBY", "enqueue_time": 0, "query_time": 35,
        "intervals": {"charging": [[20, 30]], "idle": [[25, 35]]},
    },
    "ranking_reversal_requested": {
        "test": EXPECTED_TRACE_IDENTITIES["ranking_reversal_requested"][0],
        "reason": "CONSTRAINT_BATTERY_NOT_LOW", "enqueue_time": 0,
        "query_time": 35, "intervals": {"battery-not-low": [[5, 30]]},
    },
}
EXPECTED_SCENARIO_TO_TEST = {
    scenario: identity[0] for scenario, identity in EXPECTED_TRACE_IDENTITIES.items()
}
EXPECTED_SOURCE_ENTRIES = {
    "JobStatus.java.txt": ("frameworks/base",
        "apex/jobscheduler/service/java/com/android/server/job/controllers/JobStatus.java",
        [[140, 164], [254, 263], [467, 476], [649, 658], [690, 704], [846, 892],
         [1603, 1610], [1884, 1902], [1949, 1955], [2133, 2140], [2168, 2170],
         [2183, 2219], [2261, 2315], [2397, 2589], [2680, 2758], [2801, 2838],
         [2852, 2854], [2929, 2946]], 166262, 35204,
        "b238f4fff2f10b937622c5e02b16bbb24be4f9556d777b2e52a6b5ab3d9da217"),
    "JobInfo.java.txt": ("frameworks/base",
        "apex/jobscheduler/framework/java/android/app/job/JobInfo.java", [[437, 450]],
        109481, 435, "ed060bb473d754644eaad043fc58f74ab17aa4cdc77124a31c61118ece613b55"),
    "JobScheduler.java.txt": ("frameworks/base",
        "apex/jobscheduler/framework/java/android/app/job/JobScheduler.java",
        [[143, 182], [197, 201], [223, 270], [551, 584]], 29831, 7000,
        "17f0b9244f9b9317ae1147ac480f14d9543965911b1ed6fb967b67b57349c344"),
    "job.aconfig.txt": ("frameworks/base", "apex/jobscheduler/framework/aconfig/job.aconfig",
        [[51, 64]], 2014, 690,
        "b1074013f5afdc897208a466df94909da0e58d03a3b54c39e775e335e888bfe5"),
    "get_pending_job_reason_stats_api_flag_values.textproto.txt": ("build/release",
        "aconfig/cp2a/android.app.job/get_pending_job_reason_stats_api_flag_values.textproto",
        [[1, 6]], 128, 207,
        "b8ea23cc8e155e5bd63b49f0934aeedeed808e71bf26189e598ff3446f95f1e9"),
    "api37-JobScheduler-signature.txt": ("prebuilts/sdk", "37.0/public/api/android.txt",
        [[12039, 12053]], 7278609, 1182,
        "1165a01294f83a5fa397691e273b5e6a3c4acf1ecc18fffb41d5a99c6b9fddd5"),
    "api37-finalized-flag.txt": ("prebuilts/sdk", "37.0/finalized-flags.txt",
        [[54, 58]], 62134, 318,
        "13dc5b1fea423137d0a8d3a88e99f44624d4ca940284a8cd719fe7b370f83011"),
    "JobSchedulerImpl.java.txt": ("frameworks/base",
        "apex/jobscheduler/framework/java/android/app/JobSchedulerImpl.java",
        [[42, 66], [199, 216]], 8711, 1926,
        "3d18c1f0e0a1b7d3b7f1703374456af3636c1662e5e13b3817014a7230d2a5c3"),
    "IJobScheduler.aidl.txt": ("frameworks/base",
        "apex/jobscheduler/framework/java/android/app/job/IJobScheduler.aidl",
        [[25, 49]], 2901, 1572,
        "69c171e960fd728fb41cc92f08c8375ed93d2d6635f55d0312db5846902184a1"),
    "JobSchedulerService.java.txt": ("frameworks/base",
        "apex/jobscheduler/service/java/com/android/server/job/JobSchedulerService.java",
        [[2280, 2303], [4633, 4683], [4705, 4718], [4751, 4852], [5546, 5557],
         [5946, 5964]], 326846, 11939,
        "33bce09b32460a18754883360b64e7904ca88bb3e1709f16ba50fe1e1f302e4c"),
    "BatteryController.java.txt": ("frameworks/base",
        "apex/jobscheduler/service/java/com/android/server/job/controllers/BatteryController.java",
        [[48, 54], [74, 122], [159, 215]], 11186, 6102,
        "5ae0bbe767a796d0f16c0111a9d7daf15e73d43c84ccb1afda9b45d49e4fa7ca"),
    "BatteryService.java.txt": ("frameworks/base",
        "services/core/java/com/android/server/BatteryService.java", [[894, 965]],
        90979, 4767, "7162fe96c1afec83e2dca0d80c77091032939067508a7b63704325898391985f"),
    "BatteryStatsImpl.java.txt": ("frameworks/base",
        "services/core/java/com/android/server/power/stats/BatteryStatsImpl.java",
        [[596, 613], [638, 647], [12944, 12959], [13433, 13448]], 657789, 3785,
        "568aff8ce94d3d6d41fba4490ad16ee009569a7d6a110c16f7af8597ce6edf34"),
}
EXPECTED_HISTORICAL_COMMITMENTS = {
    "execution_record": "ad58740830aa96026209119f0c9620a894ddf158525bc1bc3f3ab98d1a832f5a",
    "result_index": "bad3f9aa939df53931dfacb40317235d5dd4e813848addedcf5a91bfa8e51f7f",
    "test_result": "6aa83030b5dfc2fd2c780f36edf952f302c223c325d1bb0804f06c0b3359e39b",
    "test_patch": "0657ffd98db1ffb260868ce9e5567fe1fba1b6cc456eeb89999d18355d816898",
    "patched_test_source": "f22504c158c7dc4e5e9fe71092134037c09c12550f9b5c2706c4140ab782906e",
    "pristine_test_source": "6393bf27be4ae1baa7a0e4bbf7ae7bfbc1965cd4d97fa6456490eb6f577b8cbe",
    "job_status_source": "2a8fbe2a30f1967d677ebc9303446bd6833cb280bab11f3190a2bdb87450e7ba",
    "stdout": "76773015f0a5dbb4ec411d0d9d1948998c602fceabc911ea7f5052f9199b5601",
    "device_logcat": "f2ba9fe5768922ffead1012c2ceeebaa447723247c38b50c1c16f17a4b6f5f9b",
    "repo_manifest": "aed6cab4ac2995410b9b9feed2c20629b2b5db42d297ca109232bcdd56c923f1",
}
EXPECTED_HISTORICAL_RAW = {
    "raw/execution.json": (1581,
        "ad58740830aa96026209119f0c9620a894ddf158525bc1bc3f3ab98d1a832f5a"),
    "raw/stdout.txt": (21973,
        "76773015f0a5dbb4ec411d0d9d1948998c602fceabc911ea7f5052f9199b5601"),
    "raw/stderr.txt": (0,
        "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855"),
    "raw/device-logcat.txt": (2436232,
        "f2ba9fe5768922ffead1012c2ceeebaa447723247c38b50c1c16f17a4b6f5f9b"),
    "raw/test-result.json": (13752,
        "6aa83030b5dfc2fd2c780f36edf952f302c223c325d1bb0804f06c0b3359e39b"),
    "raw/JobStatusTest.java": (129966,
        "f22504c158c7dc4e5e9fe71092134037c09c12550f9b5c2706c4140ab782906e"),
    "raw/JobStatus.java": (166262,
        "2a8fbe2a30f1967d677ebc9303446bd6833cb280bab11f3190a2bdb87450e7ba"),
    "raw/repo-manifest.xml": (164101,
        "aed6cab4ac2995410b9b9feed2c20629b2b5db42d297ca109232bcdd56c923f1"),
    "raw/frameworks-base-status.txt": (97,
        "937517bbb564fc49cbed5e78457f1f3f7f37c118550b8d560611bf29072ea92d"),
}
EXPECTED_HISTORICAL_ARCHIVE_SHA256 = \
    "fcb3cc20e5f8083119968ff6e04ed105e48e0de9f3c80bda209b49d425baf0e7"
EXPECTED_HISTORICAL_ARCHIVE_MEMBERS = {
    "0001-sixteen-test-historical.patch", "result.json", "raw",
    *(rel for rel in EXPECTED_HISTORICAL_RAW),
}
EXPECTED_SUBSTRATE = {
    "serial": "emulator-5580",
    "product_name": "sdk_phone64_x86_64",
    "build_type": "userdebug",
    "sdk": 37,
    "release_or_codename": "Baklava",
    "fingerprint":
        "Android/sdk_phone64_x86_64/emu64x:Baklava/CP2A.260605.016/eng.upgaut:userdebug/test-keys",
}
EXPECTED_SOURCE_PARENTS = {
    "JobStatus.java.txt": "2a8fbe2a30f1967d677ebc9303446bd6833cb280bab11f3190a2bdb87450e7ba",
    "JobInfo.java.txt": "e516143f6b1befee025670defe1e5579d5e13cc1e8aabf36cce29e5ef4aba69b",
    "JobScheduler.java.txt": "e107412eebaf7d3a97916fc01fb931e37a4f4668ce32d2e6fcef51652b91aa74",
    "job.aconfig.txt": "51f540422e7bd45ea40c5d34d975f53621e1535622ff6ff92e063801d0064a30",
    "get_pending_job_reason_stats_api_flag_values.textproto.txt": "2046d376322468d26d53881775bebf99bb880624d9fde9ee6a414c6ada146b1d",
    "api37-JobScheduler-signature.txt": "120e49c34fb809f007d433d20c13de9a374c969d5a87792f2336931956581933",
    "api37-finalized-flag.txt": "22aa19ca7f5119411e46986cfde9e0ae777954566a19c8f0b733a42d91e0f6c2",
    "JobSchedulerImpl.java.txt": "9c122ee09fcab444048023ab9a6b3e7ef37c4635c5a0c059739c2e944800383e",
    "IJobScheduler.aidl.txt": "ff0b5073028e212f29195af3421817705cca63ccfce6884d97b939f5819a3150",
    "JobSchedulerService.java.txt": "2344762463a3162caa09f6e005ae830b3b1813e402758aee7988488f05d60a35",
    "BatteryController.java.txt": "8766a1113f88fbb71c6652308c55a04db686f183440aaff962119199d918b1d6",
    "BatteryService.java.txt": "f6d15a8bd2c033eb0cbffdae9eee6bc332835b20f64cf71b027797e271b058a1",
    "BatteryStatsImpl.java.txt": "5cde1b5af2d8c5f738880bd9886f2855eb957a8256e97b38bfa310c1c2f0434c",
}
HEX64 = re.compile(r"[0-9a-f]{64}\Z")
TEST_RE = re.compile(r"^\s*public void (test[A-Za-z0-9_]+)\s*\(", re.MULTILINE)
OBSERVATION_RE = re.compile(
    r"HOTMOBILE_SOURCE_OBSERVATION "
    r"scenario=(?P<scenario>[a-z0-9_]+) "
    r"present=(?P<present>true|false) "
    r"implementation=(?P<implementation>[0-9]+) "
    r"union=(?P<union>[0-9]+) "
    r"job_age=(?P<job_age>[0-9]+)"
)
ANSI_RE = re.compile(r"\x1b\[[0-9;]*m")


class VerificationError(RuntimeError):
    pass


def require(condition: bool, message: str) -> None:
    if not condition:
        raise VerificationError(message)


def load_json(path: Path) -> object:
    try:
        return json.loads(path.read_text(encoding="utf-8"))
    except (OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise VerificationError(f"cannot parse {path.relative_to(ROOT)}: {exc}") from exc


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest()


def checked_relative(value: object) -> str:
    require(isinstance(value, str) and value, "manifest path must be a nonempty string")
    require("\\" not in value and not any(ord(c) < 32 for c in value),
            f"unsafe manifest path: {value!r}")
    path = PurePosixPath(value)
    require(not path.is_absolute() and ".." not in path.parts and "." not in path.parts,
            f"unsafe manifest path: {value}")
    require(path.as_posix() == value, f"noncanonical manifest path: {value}")
    return value


def scan_tree(root: Path) -> tuple[set[str], set[str]]:
    files: set[str] = set()
    dirs: set[str] = set()

    def visit(directory: Path) -> None:
        for entry in os.scandir(directory):
            mode = entry.stat(follow_symlinks=False).st_mode
            rel = Path(entry.path).relative_to(root).as_posix()
            require(not stat.S_ISLNK(mode), f"symlink forbidden: {rel}")
            if directory == root and entry.name == ".git":
                require(stat.S_ISDIR(mode) or stat.S_ISREG(mode),
                        "root .git metadata must be a directory or regular file")
                continue
            if stat.S_ISDIR(mode):
                dirs.add(rel)
                visit(Path(entry.path))
            elif stat.S_ISREG(mode):
                files.add(rel)
            else:
                raise VerificationError(f"non-regular package entry forbidden: {rel}")

    visit(root)
    return files, dirs


def monotonicity_declared_files() -> set[str]:
    data = load_json(MONOTONICITY_PAYLOAD)
    require(isinstance(data, dict) and set(data) == {"schema_version", "files"}
            and data["schema_version"] == 1,
            "unsupported monotonicity payload manifest")
    entries = data["files"]
    require(isinstance(entries, list) and entries,
            "monotonicity payload manifest has no files")
    relative: list[str] = []
    for entry in entries:
        require(isinstance(entry, dict)
                and set(entry) == {"path", "bytes", "sha256"},
                "invalid monotonicity payload entry")
        relative.append(checked_relative(entry["path"]))
    require(relative == sorted(relative) and len(relative) == len(set(relative)),
            "monotonicity payload paths must be unique and sorted")
    prefix = MONOTONICITY_RUN.relative_to(ROOT).as_posix()
    return ({f"{prefix}/{path}" for path in relative}
            | {f"{prefix}/payload-manifest.json",
               f"{prefix}/verify_monotonicity.py"})


def verify_package_manifest() -> None:
    files, dirs = scan_tree(ROOT)
    root_files = {p for p in files if "/" not in p}
    root_dirs = {p for p in dirs if "/" not in p}
    require(root_files == EXPECTED_ROOT_FILES,
            f"top-level file scope differs: missing={sorted(EXPECTED_ROOT_FILES-root_files)}, "
            f"extra={sorted(root_files-EXPECTED_ROOT_FILES)}")
    require(root_dirs == EXPECTED_ROOT_DIRS,
            f"top-level directory scope differs: missing={sorted(EXPECTED_ROOT_DIRS-root_dirs)}, "
            f"extra={sorted(root_dirs-EXPECTED_ROOT_DIRS)}")

    build_files = {p.removeprefix("build/") for p in files if p.startswith("build/")}
    build_dirs = {p for p in dirs if p.startswith("build/")}
    require(not build_dirs, f"unexpected generated-build directory: {sorted(build_dirs)}")
    require(build_files <= EXPECTED_BUILD_FILES,
            f"unexpected generated-build file: {sorted(build_files-EXPECTED_BUILD_FILES)}")

    immutable_files = {p for p in files if p != "artifact-manifest.json"
                       and not p.startswith("build/")}
    immutable_dirs = {p for p in dirs if p != "build" and not p.startswith("build/")}
    expected_files = EXPECTED_IMMUTABLE_FILES | monotonicity_declared_files()
    expected_dirs = {
        str(parent)
        for name in expected_files
        for parent in PurePosixPath(name).parents
        if str(parent) != "."
    }
    require(immutable_files == expected_files,
            f"fixed release inventory differs: "
            f"missing={sorted(expected_files-immutable_files)}, "
            f"extra={sorted(immutable_files-expected_files)}")
    require(immutable_dirs == expected_dirs,
            f"fixed release directory inventory differs: "
            f"missing={sorted(expected_dirs-immutable_dirs)}, "
            f"extra={sorted(immutable_dirs-expected_dirs)}")
    immutable = sorted(immutable_files)
    data = load_json(MANIFEST)
    require(isinstance(data, dict) and set(data) == {"schema_version", "files"}
            and data["schema_version"] == 2, "unsupported package manifest")
    entries = data["files"]
    require(isinstance(entries, list) and entries, "package manifest has no files")
    paths = []
    for entry in entries:
        require(isinstance(entry, dict)
                and set(entry) == {"path", "bytes", "sha256"}, "invalid manifest entry")
        rel = checked_relative(entry["path"])
        require(rel != "artifact-manifest.json" and not rel.startswith("build/"),
                f"manifest must not bind mutable/generated path: {rel}")
        require(isinstance(entry["bytes"], int) and entry["bytes"] >= 0,
                f"invalid byte count: {rel}")
        require(isinstance(entry["sha256"], str) and HEX64.fullmatch(entry["sha256"]),
                f"invalid SHA-256: {rel}")
        path = ROOT / rel
        require(path.is_file(), f"manifest file missing: {rel}")
        require(path.stat().st_size == entry["bytes"], f"byte count mismatch: {rel}")
        require(sha256(path) == entry["sha256"], f"SHA-256 mismatch: {rel}")
        paths.append(rel)
    require(paths == sorted(paths) and len(paths) == len(set(paths)),
            "manifest paths must be unique and sorted")
    require(paths == immutable,
            f"immutable tree differs from manifest: missing={sorted(set(paths)-set(immutable))}, "
            f"extra={sorted(set(immutable)-set(paths))}")


def verify_monotonicity_run() -> None:
    completed = subprocess.run(
        [sys.executable, "-I", str(MONOTONICITY_VERIFIER)],
        cwd=MONOTONICITY_RUN,
        text=True,
        capture_output=True,
        check=False,
        env={**os.environ, "PYTHONDONTWRITEBYTECODE": "1"},
    )
    require(completed.returncode == 0,
            "monotonicity verifier failed: "
            + (completed.stderr.strip() or completed.stdout.strip()))


def apply_additive_patch(original: bytes, patch: bytes) -> bytes:
    source = original.decode("utf-8").splitlines(keepends=True)
    lines = patch.decode("utf-8").splitlines(keepends=True)
    require(sum(line.startswith("diff --git ") for line in lines) == 1,
            "patch must touch exactly one file")
    diff_line = next((line for line in lines if line.startswith("diff --git ")), "")
    require(diff_line.endswith(
        "a/services/tests/mockingservicestests/src/com/android/server/job/controllers/JobStatusTest.java "
        "b/services/tests/mockingservicestests/src/com/android/server/job/controllers/JobStatusTest.java\n"),
        "patch target is not JobStatusTest.java")
    hunks: list[tuple[int, list[str]]] = []
    index = 0
    while index < len(lines):
        match = re.match(r"@@ -(\d+)(?:,\d+)? \+(\d+)(?:,\d+)? @@", lines[index])
        if not match:
            index += 1
            continue
        body: list[str] = []
        old_start = int(match.group(1))
        index += 1
        while index < len(lines) and not lines[index].startswith("@@ "):
            line = lines[index]
            if line.startswith(("diff --git ", "index ", "--- ", "+++ ")):
                index += 1
                continue
            if not line.startswith((" ", "+", "-", "\\ No newline")):
                index += 1
                continue
            if line == "-- \n":
                index += 1
                continue
            if line.startswith("\\ No newline"):
                index += 1
                continue
            require(line[:1] in {" ", "+", "-"}, "unsupported unified-diff line")
            require(not line.startswith("-"), "scoped patch must not delete source lines")
            body.append(line)
            index += 1
        hunks.append((old_start, body))
    require(len(hunks) == 2, f"expected two additive hunks, found {len(hunks)}")
    output: list[str] = []
    cursor = 0
    for old_start, body in hunks:
        target = old_start - 1
        require(target >= cursor, "overlapping patch hunks")
        output.extend(source[cursor:target])
        cursor = target
        for line in body:
            if line[0] == " ":
                require(cursor < len(source) and source[cursor] == line[1:],
                        f"patch context mismatch at source line {cursor + 1}")
                output.append(line[1:])
                cursor += 1
            else:
                output.append(line[1:])
    output.extend(source[cursor:])
    return "".join(output).encode("utf-8")


def load_json_bytes(raw: bytes, label: str) -> object:
    try:
        return json.loads(raw.decode("utf-8"))
    except (UnicodeError, json.JSONDecodeError) as exc:
        raise VerificationError(f"cannot parse {label}: {exc}") from exc


def verify_patch(scope: dict[str, object]) -> tuple[set[str], set[str]]:
    require(sha256(PATCH) == EXPECTED_CRITICAL_HASHES["patch"], "scoped patch digest mismatch")
    require(sha256(PRE_PATCH) == EXPECTED_CRITICAL_HASHES["pre_patch"],
            "pristine test digest mismatch")
    require(sha256(EXECUTED_TEST) == EXPECTED_CRITICAL_HASHES["executed_test"],
            "executed test digest mismatch")
    reconstructed = apply_additive_patch(PRE_PATCH.read_bytes(), PATCH.read_bytes())
    require(hashlib.sha256(reconstructed).hexdigest() == EXPECTED_CRITICAL_HASHES["executed_test"],
            "reconstructed test digest mismatch")
    require(reconstructed == EXECUTED_TEST.read_bytes(),
            "reconstructed source differs from executed source")

    pristine = set(TEST_RE.findall(PRE_PATCH.read_text(encoding="utf-8")))
    executed = set(TEST_RE.findall(EXECUTED_TEST.read_text(encoding="utf-8")))
    require(len(pristine) == 71 and len(executed) == 78,
            f"unexpected test counts: {len(pristine)} pristine, {len(executed)} executed")
    require(executed - pristine == EXPECTED_PAPER_TESTS and pristine <= executed,
            "scoped patch does not add exactly the seven paper tests")
    require(set(scope["paper_result_tests"]) == EXPECTED_PAPER_TESTS,
            "scope file does not name exactly the seven paper tests")
    return pristine, executed


def parse_outcomes(path: Path) -> tuple[set[str], set[str], set[str]]:
    data = load_json(path)
    require(isinstance(data, dict), "test-result root is not an object")
    found: dict[str, list[str]] = {key: [] for key in ("PASSED", "FAILED", "IGNORED")}

    def visit(value: object) -> None:
        if isinstance(value, dict):
            for key in found:
                if key in value and isinstance(value[key], list):
                    for record in value[key]:
                        require(isinstance(record, dict) and isinstance(record.get("test_name"), str),
                                f"malformed {key} outcome")
                        found[key].append(record["test_name"])
            for key, child in value.items():
                if key not in found:
                    visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)

    visit(data)
    all_names = [name for names in found.values() for name in names]
    require(len(all_names) == len(set(all_names)), "duplicate or cross-outcome test result")
    summary = data.get("total_summary")
    require(summary == {"PASSED": len(found["PASSED"]), "FAILED": len(found["FAILED"]),
                        "IGNORED": len(found["IGNORED"])}, "test-result summary mismatch")
    require(all(name.startswith(EXPECTED_CLASS + "#") for name in all_names),
            "test-result contains a name outside JobStatusTest")
    strip_class = lambda name: name.split("#", 1)[1]
    return tuple({strip_class(name) for name in found[key]} for key in ("PASSED", "FAILED", "IGNORED"))


def fully_qualified_outcomes_data(data: object) -> tuple[set[str], set[str], set[str]]:
    found: dict[str, list[str]] = {key: [] for key in ("PASSED", "FAILED", "IGNORED")}

    def visit(value: object) -> None:
        if isinstance(value, dict):
            for key in found:
                records = value.get(key)
                if isinstance(records, list):
                    for record in records:
                        require(isinstance(record, dict)
                                and isinstance(record.get("test_name"), str),
                                f"malformed historical {key} outcome")
                        found[key].append(record["test_name"])
            for key, child in value.items():
                if key not in found:
                    visit(child)
        elif isinstance(value, list):
            for child in value:
                visit(child)

    visit(data)
    names = [name for group in found.values() for name in group]
    require(len(names) == len(set(names)), "duplicate historical test outcome")
    return tuple(set(found[key]) for key in ("PASSED", "FAILED", "IGNORED"))


def verify_run(executed_methods: set[str]) -> dict[str, dict[str, object]]:
    require(sha256(EXECUTION) == EXPECTED_CRITICAL_HASHES["execution"],
            "execution-record digest mismatch")
    require(sha256(RESULT) == EXPECTED_CRITICAL_HASHES["result"],
            "result-index digest mismatch")
    require(sha256(REVISIONS) == EXPECTED_CRITICAL_HASHES["revisions"],
            "revision-record digest mismatch")
    require(sha256(TEST_RESULT) == EXPECTED_CRITICAL_HASHES["test_result"],
            "test-result digest mismatch")
    require(sha256(ATEST_LOG) == EXPECTED_CRITICAL_HASHES["atest_log"],
            "atest-log digest mismatch")
    require(sha256(DEVICE_LOG) == EXPECTED_CRITICAL_HASHES["device_log"],
            "device-log digest mismatch")
    require(sha256(STATUS) == EXPECTED_CRITICAL_HASHES["status"], "status digest mismatch")
    require(STATUS.read_text(encoding="utf-8") == EXPECTED_STATUS,
            "scoped patch was not the sole frameworks/base modification")

    result = load_json(RESULT)
    require(isinstance(result, dict) and result.get("schema_version") == 1
            and result.get("kind") == "hotmobile-paper-scoped-execution-index",
            "unexpected scoped result index")
    roles = result.get("roles")
    require(isinstance(roles, dict) and set(roles) == set(EXPECTED_ROLES),
            "scoped result roles are not exact")
    for role, (name, media) in EXPECTED_ROLES.items():
        entry = roles[role]
        require(isinstance(entry, dict)
                and set(entry) == {"path", "media_type", "bytes", "sha256"},
                f"invalid result role: {role}")
        require(entry["path"] == name and entry["media_type"] == media,
                f"wrong path or media type for result role: {role}")
        path = RUN / name
        require(path.stat().st_size == entry["bytes"] and sha256(path) == entry["sha256"],
                f"result role digest mismatch: {role}")
    require({p.name for p in RUN.iterdir() if p.is_file()} ==
            {"result.json", *(name for name, _ in EXPECTED_ROLES.values())},
            "unindexed scoped-run evidence file")

    execution = load_json(EXECUTION)
    require(isinstance(execution, dict) and execution.get("schema_version") == 3
            and execution.get("kind") == "hotmobile-paper-scoped-aosp-jobstatus-execution",
            "unexpected execution record")
    require(execution.get("revision") == EXPECTED_REVISION
            and execution.get("build_target") == EXPECTED_TARGET
            and execution.get("test_class") == EXPECTED_CLASS
            and execution.get("exit_code") == 0, "execution identity mismatch")
    require(execution.get("command_argv") == ["atest", "-s", "emulator-5580",
            f"{EXPECTED_TARGET}:{EXPECTED_CLASS}"], "unexpected atest command")
    require(execution.get("started_utc") == "2026-08-13T04:35:27Z"
            and execution.get("finished_utc") == "2026-08-13T04:51:43Z",
            "execution timestamp commitment mismatch")
    start = datetime.fromisoformat(execution["started_utc"].replace("Z", "+00:00"))
    finish = datetime.fromisoformat(execution["finished_utc"].replace("Z", "+00:00"))
    require(start < finish, "execution timestamps are not ordered")
    require(execution.get("substrate") == EXPECTED_SUBSTRATE,
            "execution substrate mismatch")
    require(execution.get("outcomes") == {"upstream": 71, "added": 7, "passed": 78,
            "failed": 0, "ignored": 0, "assumption_failed": 0},
            "execution outcome summary mismatch")
    hashes = execution.get("sha256")
    require(isinstance(hashes, dict), "execution digest map missing")
    cross = {
        "test_patch": sha256(PATCH), "pristine_test_source": sha256(PRE_PATCH),
        "executed_test_source": sha256(EXECUTED_TEST), "test_result": sha256(TEST_RESULT),
        "atest_log": sha256(ATEST_LOG), "device_logcat": sha256(DEVICE_LOG),
        "frameworks_base_status": sha256(STATUS),
    }
    for key, value in cross.items():
        require(hashes.get(key) == value, f"execution cross-digest mismatch: {key}")
    require(hashes.get("production_job_status_source") == EXPECTED_CRITICAL_HASHES["job_status"],
            "execution JobStatus digest mismatch")
    require(execution.get("installed_test_apk_archived") is False
            and execution.get("installed_test_apk_bytes") == 123290760
            and hashes.get("installed_test_apk") ==
            "02ca24472fd10ea793060d25fed967c68fba59d32ff30381839eefba22c27fe5",
            "installed test APK commitment mismatch")

    revisions = load_json(REVISIONS)
    require(isinstance(revisions, dict) and revisions.get("projects") == EXPECTED_PROJECTS,
            "relevant project revisions mismatch")
    require(hashes.get("complete_repo_manifest") == revisions.get("complete_repo_manifest_sha256"),
            "repo-manifest commitment mismatch")

    passed, failed, ignored = parse_outcomes(TEST_RESULT)
    require(passed == executed_methods and not failed and not ignored,
            f"JUnit outcomes differ from executed source: {len(passed)}/0/0 expected 78/0/0")
    log_text = ANSI_RE.sub("", ATEST_LOG.read_text(encoding="utf-8", errors="strict"))
    summary = "Passed: 78, Failed: 0, Ignored: 0, Assumption Failed: 0"
    require(log_text.count(summary) == 1 and log_text.count("All tests passed!") == 1,
            "atest log does not contain one exact 78/0/0/0 summary")

    device = DEVICE_LOG.read_text(encoding="utf-8", errors="replace")
    marker_lines = [line for line in device.splitlines() if "HOTMOBILE_SOURCE_OBSERVATION" in line]
    require(len(marker_lines) == 8, f"expected eight observation lines, found {len(marker_lines)}")
    records: dict[str, dict[str, object]] = {}
    for line in marker_lines:
        match = OBSERVATION_RE.search(line)
        require(match is not None and match.end() == len(line), f"malformed observation: {line}")
        scenario = match.group("scenario")
        require(scenario not in records, f"duplicate observation: {scenario}")
        records[scenario] = {
            "present": match.group("present") == "true",
            "implementation": int(match.group("implementation")),
            "union": int(match.group("union")),
            "job_age": int(match.group("job_age")),
        }
    require(set(records) == EXPECTED_SCENARIOS, "observation scenario set mismatch")

    def test_slice(name: str) -> str:
        start_marker = f"started: {name}("
        finish_marker = f"finished: {name}("
        require(device.count(start_marker) == 1 and device.count(finish_marker) == 1,
                f"device-log test markers are not unique: {name}")
        begin = device.find(start_marker)
        end = device.find(finish_marker, begin + 1)
        require(begin >= 0 and end > begin, f"device-log test slice missing: {name}")
        return device[begin:end]

    for scenario, test in EXPECTED_SCENARIO_TO_TEST.items():
        matches = OBSERVATION_RE.findall(test_slice(test))
        sliced_scenarios = [match[0] for match in matches]
        require(sliced_scenarios.count(scenario) == 1,
                f"observation is not inside its expected test slice: {scenario}")

    focal = test_slice("testPendingReasonStats_samePublicReasonChargingFirstCloseCharacterization")
    require(focal.count("Unsatisfied constraint not being tracked: BATTERY_NOT_LOW") == 1,
            "focal intermediate-query warning mismatch")
    for name in ("testPendingReasonStats_samePublicReasonChargingFirstCloseQueryFreeCharacterization",
                 "testPendingReasonStats_rankingReversalCharacterization"):
        require("Unsatisfied constraint not being tracked" not in test_slice(name),
                f"headline final-query slice unexpectedly warns: {name}")
    require(device.count("Unsatisfied constraint not being tracked") == 1,
            "unexpected warning elsewhere in scoped run")
    require("assertArrayEquals(new long[] { 0, 0, 10, 50 }, observed);" in
            EXECUTED_TEST.read_text(encoding="utf-8"), "focal checkpoint assertion missing")
    return records


def interval_metrics(trace: dict[str, object]) -> tuple[int, int, int, dict[frozenset[str], int]]:
    enqueue = trace.get("enqueue_time")
    query = trace.get("query_time")
    intervals = trace.get("intervals")
    require(type(enqueue) is int and type(query) is int and enqueue <= query,
            "invalid enqueue/query time")
    require(isinstance(intervals, dict), "trace intervals must be an object")
    flat: list[tuple[int, int, str]] = []
    additive = 0
    for contributor, ranges in intervals.items():
        require(isinstance(contributor, str) and isinstance(ranges, list),
                "invalid contributor intervals")
        last_end = enqueue
        for pair in ranges:
            require(isinstance(pair, list) and len(pair) == 2
                    and all(type(x) is int for x in pair), "invalid interval")
            start, end = pair
            require(enqueue <= start < end <= query and start >= last_end,
                    f"invalid or overlapping interval for {contributor}")
            last_end = end
            additive += end - start
            flat.append((start, end, contributor))
    points = sorted({enqueue, query, *(x for start, end, _ in flat for x in (start, end))})
    states: dict[frozenset[str], int] = {}
    for left, right in zip(points, points[1:]):
        active = frozenset(name for start, end, name in flat if start <= left < end)
        states[active] = states.get(active, 0) + right - left
    union = sum(duration for active, duration in states.items() if active)
    return query - enqueue, union, additive, states


def verify_traces(records: dict[str, dict[str, object]]) -> None:
    require(sha256(TRACES) == EXPECTED_CRITICAL_HASHES["traces"],
            "trace-definition digest mismatch")
    data = load_json(TRACES)
    require(isinstance(data, dict) and data.get("schema_version") == 2
            and data.get("interval_convention") == "half-open [start,end)",
            "unexpected trace schema")
    traces = data.get("traces")
    require(isinstance(traces, dict) and set(traces) == EXPECTED_SCENARIOS,
            "trace scenario set mismatch")
    require(traces == EXPECTED_TRACE_RECORDS, "trace definitions differ from executed scenarios")
    derived: dict[str, tuple[int, int, int, dict[frozenset[str], int]]] = {}
    for scenario, trace in traces.items():
        require(isinstance(trace, dict), f"invalid trace: {scenario}")
        require((trace.get("test"), trace.get("reason")) == EXPECTED_TRACE_IDENTITIES[scenario],
                f"trace identity mismatch: {scenario}")
        derived[scenario] = interval_metrics(trace)
        age, union, _additive, _states = derived[scenario]
        observed = records[scenario]
        require(observed["present"] is True, f"reason key absent: {scenario}")
        require(observed["union"] == union and observed["job_age"] == age,
                f"test-supplied fields disagree with intervals: {scenario}")

    expected = {
        "one_predicate_control": (30, 30, 30, 40),
        "nonoverlap_control": (20, 20, 20, 40),
        "overlap_charging_first_close_query_free": (50, 30, 40, 40),
        "overlap_charging_first_close": (50, 30, 40, 40),
        "overlap_battery_not_low_first_close": (50, 30, 40, 40),
        "membership_removal": (0, 15, 20, 25),
        "ranking_reversal_standby": (40, 15, 20, 35),
        "ranking_reversal_requested": (25, 25, 25, 35),
    }
    for scenario, (implementation, union, additive, age) in expected.items():
        d_age, d_union, d_additive, _ = derived[scenario]
        require((records[scenario]["implementation"], d_union, d_additive, d_age) ==
                (implementation, union, additive, age), f"paper values mismatch: {scenario}")
    require(expected["ranking_reversal_requested"][0] <
            expected["ranking_reversal_standby"][0], "implementation ranking did not reverse")
    require(expected["ranking_reversal_requested"][0] >
            expected["ranking_reversal_standby"][2] >
            expected["ranking_reversal_standby"][1], "reference ranking mismatch")

    def duration(scenario: str, members: set[str]) -> int:
        return derived[scenario][3].get(frozenset(members), 0)

    c = Fraction(records["one_predicate_control"]["implementation"],
                 duration("one_predicate_control", {"charging"}))
    nonoverlap_total = records["nonoverlap_control"]["implementation"]
    b = Fraction(nonoverlap_total - duration("nonoverlap_control", {"charging"}) * c,
                 duration("nonoverlap_control", {"battery-not-low"}))
    overlap_total = records["overlap_charging_first_close_query_free"]["implementation"]
    pair = Fraction(overlap_total
                    - duration("overlap_charging_first_close_query_free", {"charging"}) * c
                    - duration("overlap_charging_first_close_query_free", {"battery-not-low"}) * b,
                    duration("overlap_charging_first_close_query_free",
                             {"charging", "battery-not-low"}))
    require((c, b, pair) == (1, 1, 3), "fixed-rate premises did not derive 1,1,3")
    predicted = (duration("membership_removal", {"charging"}) * c
                 + duration("membership_removal", {"charging", "battery-not-low"}) * pair)
    require(predicted == 25 and records["membership_removal"]["implementation"] == 0,
            "four-trace fixed-rate contradiction not reproduced")


def verify_historical(pristine_methods: set[str]) -> None:
    require(sha256(HISTORICAL) == EXPECTED_CRITICAL_HASHES["historical"],
            "historical commitment-record digest mismatch")
    require(sha256(HISTORICAL_NAMES) == EXPECTED_CRITICAL_HASHES["historical_names"],
            "historical name-projection digest mismatch")
    data = load_json(HISTORICAL)
    require(isinstance(data, dict) and data.get("schema_version") == 1,
            "unexpected historical-count schema")
    require(data.get("frameworks_base_revision") == EXPECTED_REVISION,
            "historical revision mismatch")
    require(data.get("counts") == {"upstream": 71, "added": 16, "passed": 87,
            "failed": 0, "ignored": 0, "assumption_failed": 0},
            "historical aggregate counts mismatch")
    require(len(pristine_methods) + data["counts"]["added"] == data["counts"]["passed"],
            "historical 71+16=87 relationship failed")
    commitments = data.get("sha256_commitments")
    require(commitments == EXPECTED_HISTORICAL_COMMITMENTS,
            "historical file commitments mismatch")
    projection = load_json(HISTORICAL_NAMES)
    require(isinstance(projection, dict) and projection.get("schema_version") == 1
            and projection.get("source_test_result_sha256") == commitments.get("test_result"),
            "historical test-name projection provenance mismatch")
    hashes = projection.get("passed_name_sha256")
    require(isinstance(hashes, list) and hashes == sorted(hashes)
            and len(hashes) == len(set(hashes)) == 87
            and all(isinstance(value, str) and HEX64.fullmatch(value) for value in hashes),
            "historical passed-name hash set is not 87 unique SHA-256 values")
    historical = set(hashes)
    qualify = lambda name: f"{EXPECTED_CLASS}#{name}"
    upstream = {hashlib.sha256(qualify(name).encode("utf-8")).hexdigest()
                for name in pristine_methods}
    paper = {hashlib.sha256(qualify(name).encode("utf-8")).hexdigest()
             for name in EXPECTED_PAPER_TESTS}
    require(upstream <= historical and paper <= historical,
            "historical pass set lacks an upstream or paper test")
    require(len(historical - upstream) == 16
            and len((historical - upstream) - paper) == 9,
            "historical pass projection is not 16 additions with nine outside the active set")

    require(sha256(HISTORICAL_ARCHIVE) == EXPECTED_HISTORICAL_ARCHIVE_SHA256,
            "sealed historical archive digest mismatch")
    members: dict[str, bytes] = {}
    try:
        with tarfile.open(HISTORICAL_ARCHIVE, mode="r:gz") as archive:
            archive_members = archive.getmembers()
            require(len(archive_members) == len(EXPECTED_HISTORICAL_ARCHIVE_MEMBERS),
                    "sealed historical archive member count mismatch")
            for member in archive_members:
                require(member.name in EXPECTED_HISTORICAL_ARCHIVE_MEMBERS,
                        f"unexpected sealed historical member: {member.name}")
                require(not member.issym() and not member.islnk()
                        and (member.isfile() or member.isdir()),
                        f"unsafe sealed historical member: {member.name}")
                if member.isfile():
                    handle = archive.extractfile(member)
                    require(handle is not None, f"cannot read sealed member: {member.name}")
                    members[member.name] = handle.read()
    except (OSError, tarfile.TarError) as exc:
        raise VerificationError(f"cannot inspect sealed historical archive: {exc}") from exc
    require(set(members) == EXPECTED_HISTORICAL_ARCHIVE_MEMBERS - {"raw"},
            "sealed historical file inventory mismatch")

    result = load_json_bytes(members["result.json"], "sealed historical result.json")
    require(isinstance(result, dict) and result.get("schema_version") == 3
            and result.get("kind") == "aosp-jobstatus-union-execution",
            "unexpected historical result index")
    indexed = result.get("raw_files")
    require(isinstance(indexed, list) and len(indexed) == len(EXPECTED_HISTORICAL_RAW),
            "historical raw-file inventory mismatch")
    seen: set[str] = set()
    for entry in indexed:
        require(isinstance(entry, dict), "malformed historical result entry")
        rel = entry.get("path")
        require(rel in EXPECTED_HISTORICAL_RAW and rel not in seen,
                f"unexpected historical raw file: {rel}")
        seen.add(rel)
        expected_bytes, expected_sha = EXPECTED_HISTORICAL_RAW[rel]
        require(entry.get("bytes") == expected_bytes and entry.get("sha256") == expected_sha
                and len(members[rel]) == expected_bytes
                and hashlib.sha256(members[rel]).hexdigest() == expected_sha,
                f"historical raw-file mismatch: {rel}")
    require(seen == set(EXPECTED_HISTORICAL_RAW), "historical raw file missing")
    require(hashlib.sha256(members["result.json"]).hexdigest() ==
            EXPECTED_HISTORICAL_COMMITMENTS["result_index"],
            "historical result-index digest mismatch")
    historical_patch = members["0001-sixteen-test-historical.patch"]
    require(hashlib.sha256(historical_patch).hexdigest() ==
            EXPECTED_HISTORICAL_COMMITMENTS["test_patch"],
            "historical patch digest mismatch")
    historical_reconstructed = apply_additive_patch(
        PRE_PATCH.read_bytes(), historical_patch)
    archived_test = members["raw/JobStatusTest.java"]
    require(historical_reconstructed == archived_test,
            "historical patch does not reconstruct archived test source")
    historical_methods = set(TEST_RE.findall(archived_test.decode("utf-8")))
    require(pristine_methods <= historical_methods and len(historical_methods) == 87
            and len(historical_methods - pristine_methods) == 16,
            "historical source does not contain exactly 71+16 tests")
    historical_result = load_json_bytes(members["raw/test-result.json"],
                                        "sealed historical test-result.json")
    passed_fq, failed_fq, ignored_fq = fully_qualified_outcomes_data(historical_result)
    expected_fq = {f"{EXPECTED_CLASS}#{name}" for name in historical_methods}
    require(passed_fq == expected_fq and not failed_fq and not ignored_fq,
            "historical result is not exactly 87 passed and 0 failed/ignored")
    regenerated_projection = sorted(hashlib.sha256(name.encode("utf-8")).hexdigest()
                                    for name in passed_fq)
    require(regenerated_projection == hashes,
            "historical name-hash projection does not match sealed result")


def verify_sources() -> None:
    require(sha256(SOURCE_MANIFEST) == EXPECTED_CRITICAL_HASHES["source_manifest"],
            "source-manifest digest mismatch")
    data = load_json(SOURCE_MANIFEST)
    require(isinstance(data, dict) and data.get("schema_version") == 1
            and data.get("aosp_tag") == "android-17.0.0_r1"
            and data.get("projects") == EXPECTED_PROJECTS, "source provenance mismatch")
    entries = data.get("files")
    require(isinstance(entries, list) and len(entries) == len(EXPECTED_SOURCE_PARENTS),
            "unexpected source-excerpt inventory")
    names: set[str] = set()
    for entry in entries:
        require(isinstance(entry, dict), "malformed source manifest entry")
        name = entry.get("artifact_path")
        require(name in EXPECTED_SOURCE_PARENTS and name not in names,
                f"unexpected or duplicate source excerpt: {name}")
        names.add(name)
        expected_project, expected_path, expected_ranges, expected_full_bytes, \
            expected_excerpt_bytes, expected_excerpt_sha = EXPECTED_SOURCE_ENTRIES[name]
        require(entry.get("project") == expected_project
                and entry.get("upstream_path") == expected_path
                and entry.get("ranges") == expected_ranges
                and entry.get("full_bytes") == expected_full_bytes
                and entry.get("excerpt_bytes") == expected_excerpt_bytes
                and entry.get("excerpt_sha256") == expected_excerpt_sha
                and entry.get("full_sha256") == EXPECTED_SOURCE_PARENTS[name]
                and entry.get("project_revision") == EXPECTED_PROJECTS[expected_project],
                f"source parent provenance mismatch: {name}")
        path = EXCERPTS / name
        require(path.stat().st_size == entry.get("excerpt_bytes")
                and sha256(path) == entry.get("excerpt_sha256"),
                f"source excerpt digest mismatch: {name}")
        ranges = entry.get("ranges")
        require(isinstance(ranges, list) and ranges, f"source ranges missing: {name}")
        expected_lines = sum(end - start + 1 for start, end in ranges)
        numbered = [line for line in path.read_text(encoding="utf-8").splitlines()
                    if re.match(r"\d{6}: ", line)]
        require(len(numbered) == expected_lines, f"source excerpt line count mismatch: {name}")
    require(names == set(EXPECTED_SOURCE_PARENTS), "source excerpts missing")

    markers = {
        "JobStatus.java.txt": ["IMPLICIT_CONSTRAINTS", "mPendingJobReasonsStats",
            "constraintToPendingJobReason", "updatePendingJobReasonStats", "isReady("],
        "JobScheduler.java.txt": ["getPendingJobReasonStats", "FLAG_GET_PENDING_JOB_REASON_STATS_API"],
        "JobSchedulerImpl.java.txt": ["mBinder.getPendingJobReasonStats"],
        "IJobScheduler.aidl.txt": ["getPendingJobReasonStats"],
        "JobSchedulerService.java.txt": ["job.getPendingJobReasonStats", "ACTION_BATTERY_OKAY",
            "ACTION_CHARGING", "isConsideredCharging"],
        "BatteryController.java.txt": ["hasTopExemptionLocked"],
        "BatteryService.java.txt": ["ACTION_BATTERY_OKAY"],
        "BatteryStatsImpl.java.txt": ["ACTION_CHARGING", "mCharging"],
        "job.aconfig.txt": ["get_pending_job_reason_stats_api", "enhanced_pending_and_stop_reasons_api"],
        "get_pending_job_reason_stats_api_flag_values.textproto.txt": ["ENABLED", "READ_ONLY"],
        "api37-JobScheduler-signature.txt": ["public abstract class JobScheduler",
            "getPendingJobReasonStats"],
        "api37-finalized-flag.txt": ["android.app.job.get_pending_job_reason_stats_api"],
        "JobInfo.java.txt": ["CONSTRAINT_FLAG_CHARGING", "CONSTRAINT_FLAG_BATTERY_NOT_LOW",
            "CONSTRAINT_FLAG_DEVICE_IDLE"],
    }
    for name, required in markers.items():
        text = (EXCERPTS / name).read_text(encoding="utf-8")
        require(all(marker in text for marker in required), f"source sanity marker missing: {name}")


def main() -> int:
    try:
        verify_package_manifest()
        scope = load_json(SCOPE)
        require(sha256(SCOPE) == EXPECTED_CRITICAL_HASHES["scope"],
                "scope-definition digest mismatch")
        require(isinstance(scope, dict) and scope.get("schema_version") == 2
                and scope.get("frameworks_base_revision") == EXPECTED_REVISION,
                "unexpected scope schema")
        pristine, executed = verify_patch(scope)
        records = verify_run(executed)
        verify_traces(records)
        verify_historical(pristine)
        verify_monotonicity_run()
        verify_sources()
    except VerificationError as exc:
        print(f"FAIL: {exc}", file=sys.stderr)
        return 1
    print("PASS: paper-scoped artifact is internally consistent")
    print("  fresh execution: 78 passed = 71 upstream + 7 paper tests; 0 failed/ignored/assumption-failed")
    print("  paper observations: 8; production JobStatus.java unchanged")
    print("  focal values: implementation 50; union 30; additive 40; age 40")
    print("  ranking: implementation 40>25; references 25>20>15")
    print("  historical manuscript count recorded: 87 passed = 71 upstream + 16 added")
    print("  monotonicity variant recorded: focused 1 pass; full class 68 pass + 4 assumptions")
    print("  monotonicity provenance: post-hoc source binding; executed APK not archived")
    print("  out of scope: app-facing execution, controller execution, prevalence, repair evaluation")
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

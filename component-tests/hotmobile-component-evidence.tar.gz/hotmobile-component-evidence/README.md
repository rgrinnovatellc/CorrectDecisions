# Lost Boundaries: Toward Accountable Diagnostic Metrics

This directory contains the paper and its non-anonymized, paper-scoped
supplemental artifact. It is intentionally independent of the surrounding
full-paper repository.

It can be copied or renamed and used as the root of a new Git repository. No
file in a parent repository is required to verify the evidence or build the
paper. Root-level Git metadata is ignored by the artifact verifier; all release
content remains subject to its fixed inventory and digest checks.

## Project map

- `build/hotmobile2027.pdf` is the current six-page paper.
- `supplemental.md` gives a short, human-readable account of the paper traces.
- `artifact/` contains the scoped tests, executed evidence, pinned source
  excerpts, claim map, provenance, and reproduction instructions.
- `SCOPE.md` defines what this workshop project does and does not claim.
- `verify_artifact.py` audits the package offline using only Python's standard
  library.

## Start a standalone repository

After copying this directory and choosing its new name:

```sh
git init
python3 -I verify_artifact.py
git add --all
git commit -m "Initial paper and artifact release"
```

The included `.gitignore` keeps intermediate paper-build files out of Git while
retaining the PDF, and `.gitattributes` preserves the byte-level evidence across
normal clones. Before publishing the repository for reuse, the authors should
choose a license for the manuscript and project-authored code and documentation.
The included Android notices cover upstream material but do not make that
project-license choice; see `artifact/LICENSES/README.md`.

## Verify offline

```sh
python3 -I verify_artifact.py
```

Python 3.10 or newer is required; no third-party package or Android checkout is
needed. The verifier checks the exact seven-test patch, all 78 outcomes in the
fresh scoped run, eight paper observations, source provenance, interval
arithmetic, ranking reversal, and the cross-trace consistency argument. It also
checks the digest-bound historical 16-added-test/87-pass archive that supports
the manuscript's method claim. Only the seven active tests' eight logged
observations are paper findings; the other nine tests serve only the named
method-coverage claim.

## Build the paper

```sh
make paper
```

The build requires a TeX toolchain, `curl`, and `sha256sum`. It downloads the
ACM class and bibliography style from the pinned commit in `Makefile`, verifies
their digests, and writes generated files under `build/`. Those generated files
are convenience outputs rather than artifact evidence and are not bound by the
artifact manifest.

Read [SCOPE.md](SCOPE.md) before interpreting evidence. The Android probe app,
device-study matrices, cross-version work, and repair experiments are outside
this workshop paper.
